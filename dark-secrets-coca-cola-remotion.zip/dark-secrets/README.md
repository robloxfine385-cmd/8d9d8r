# Dark Secrets of Coca-Cola — Remotion (Main · 1920×1080 · 60 FPS · 2700 frames)

    npm install
    npm start             # Remotion Studio
    npm run render:draft  # half-res check
    npm run render        # final → out/dark-secrets.mp4

- `public/voice.mp3` is a SILENT 45 s placeholder — replace it with the narration (same filename).
- Loud narration onsets (via @remotion/media-utils) + scripted bass-drop cues (`CUES` in src/constants/dialogs.ts) drive shake / chromatic aberration / glitch.
- SFX are original synthesized WAVs in public/sfx (`npm run assets` regenerates them).
