import React from "react";
import { Composition } from "remotion";
import { DarkSecretsComposition } from "./Composition";
import { FPS, HEIGHT, TOTAL_FRAMES, WIDTH } from "./constants/dialogs";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={DarkSecretsComposition}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
