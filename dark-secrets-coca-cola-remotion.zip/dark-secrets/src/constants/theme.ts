// Typography engine: every font is loaded through Remotion's loadFont API so
// glyphs are ready before the first frame renders (no layout shift, no fallback flash).
import { loadFont as loadHindSiliguri } from "@remotion/google-fonts/HindSiliguri";
import { loadFont as loadNotoBengali } from "@remotion/google-fonts/NotoSansBengali";
import { loadFont as loadBebas } from "@remotion/google-fonts/BebasNeue";
import { loadFont as loadPlayfair } from "@remotion/google-fonts/PlayfairDisplay";
import { loadFont as loadJetBrains } from "@remotion/google-fonts/JetBrainsMono";

const hind = loadHindSiliguri("normal", { weights: ["500", "600", "700"], subsets: ["bengali", "latin"] });
const noto = loadNotoBengali("normal", { weights: ["800", "900"], subsets: ["bengali"] });
const bebas = loadBebas("normal", { weights: ["400"], subsets: ["latin"] });
const playfair = loadPlayfair("normal", { weights: ["700", "900"], subsets: ["latin"] });
const mono = loadJetBrains("normal", { weights: ["500", "700"], subsets: ["latin"] });

export const FONT = {
  bengaliHero: `${noto.fontFamily}, ${hind.fontFamily}, sans-serif`,
  bengaliBody: `${hind.fontFamily}, sans-serif`,
  latinHero: `${bebas.fontFamily}, ${hind.fontFamily}, sans-serif`,
  serif: `${playfair.fontFamily}, serif`,
  mono: `${mono.fontFamily}, monospace`,
} as const;

export const C = {
  bg: "#04050a",
  ink: "#0a0b10",
  red: "#ff1730",
  redDeep: "#7a0612",
  toxic: "#39ff14",
  amber: "#ffb020",
  sepia: "#c9a468",
  steel: "#8d99a8",
  white: "#f4f6fa",
  cyan: "#00e5ff",
} as const;
