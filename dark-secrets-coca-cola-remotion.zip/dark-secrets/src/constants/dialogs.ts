export const FPS = 60;
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const TOTAL_FRAMES = 2700; // exactly 45 s @ 60 fps

export type SceneKey = "s1" | "s2" | "s3" | "s4";

/** Contiguous, gap-free scene windows (global frames). 480 + 720 + 900 + 600 = 2700 */
export const SCENES: Record<SceneKey, { from: number; dur: number; name: string }> = {
  s1: { from: 0, dur: 480, name: "S1 · Secret Vault" },
  s2: { from: 480, dur: 720, name: "S2 · 1886" },
  s3: { from: 1200, dur: 900, name: "S3 · Sugar & Acid" },
  s4: { from: 2100, dur: 600, name: "S4 · Outro" },
};

export const DIALOGS = {
  s1: {
    chapter: "দ্য সিক্রেট ভল্ট",
    overlay: "কোকাকোলার আসল ফর্মুলা কোথায় লুকানো?",
    voiceover:
      "আপনি কি জানেন কোকাকোলা কোম্পানি তাদের আসল ফর্মুলা দুনিয়ার সবার থেকে কেন লুকিয়ে রাখে? এমনকী মাত্র দুজন মানুষ এই সিক্রেট রেসিপি জানেন!",
  },
  s2: {
    chapter: "১৮৮৬ সালের নিষিদ্ধ ইতিহাস",
    overlay: "১৮৮৬ সালের আসল কোকা পাতা!",
    voiceover:
      "শুরুতে ১৮৮৬ সালে কোকাকোলার মধ্যে আসল কোকা পাতার নির্যাস মেশানো হতো—যা ড্রাগ হিসেবে পরিচিত ছিল! যদিও পরে সেটা নিষিদ্ধ করা হয়।",
  },
  s3: {
    chapter: "চিনি ও অ্যাসিডের সত্য",
    overlay: "১০ চামচ চিনি + ফসফরিক অ্যাসিড!",
    voiceover:
      "কিন্তু আজও এক বোতল ড্রিংকসে থাকে প্রায় ১০ চামচ পরিমাণ চিনি, যা শরীরে ঢোকার সাথে সাথে ইনসুলিন স্পাইক ঘটায়! আর এর ফসফরিক অ্যাসিড মরচে ধরা লোহাকেও পরিষ্কার করতে পারে!",
  },
  s4: {
    chapter: "সতর্কতা ও আউটরো",
    overlay: "সচেতন থাকুন | Subscribe to rudrarjun",
    voiceover:
      "তাহলে ভাবুন প্রতিদিন এই ড্রিংক খেয়ে শরীরের কী হাল হচ্ছে! এই ডার্ক ট্রুথটি বন্ধুদের শেয়ার করুন, আর এমন রিয়্যাল ফ্যাক্টস জানতে লাইক দিন ও rudrarjun-কে সাবস্ক্রাইব করে রাখুন!",
  },
} as const;

/** Scene-local frames of heavy bass drops / macro impact cuts / glitch bursts. */
export const CUES: Record<SceneKey, number[]> = {
  s1: [0, 120, 210, 270, 330, 410],
  s2: [0, 150, 260, 300, 540, 640],
  s3: [440, 480, 560, 700, 860],
  s4: [0, 120, 240, 360, 400, 480, 540],
};

/** Frame each word of a kinetic line pops at (start + i * per). */
export const wordFrames = (count: number, start: number, per: number) =>
  Array.from({ length: count }, (_, i) => start + i * per);

export const wordCount = (text: string) => text.split(" ").filter(Boolean).length;
