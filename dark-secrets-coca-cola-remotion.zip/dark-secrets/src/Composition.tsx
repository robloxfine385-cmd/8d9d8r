import React from "react";
import { AbsoluteFill, Audio, Sequence } from "remotion";
import { C } from "./constants/theme";
import { SCENES } from "./constants/dialogs";
import { CutGlitch } from "./components/GlitchFX";
import { EnergyProvider, VOICE_SRC } from "./utils/energy";
import { Scene1 } from "./scenes/Scene1";
import { Scene2 } from "./scenes/Scene2";
import { Scene3 } from "./scenes/Scene3";
import { Scene4 } from "./scenes/Scene4";

/**
 * Master timeline. EnergyProvider sits OUTSIDE the Sequences so the narration
 * analysis uses global frames; every scene reads it through useEnergy().
 */
export const DarkSecretsComposition: React.FC = () => (
  <EnergyProvider>
    <AbsoluteFill style={{ backgroundColor: C.bg }}>
      <Audio src={VOICE_SRC} volume={1} />

      <Sequence from={SCENES.s1.from} durationInFrames={SCENES.s1.dur} name={SCENES.s1.name}>
        <Scene1 />
      </Sequence>
      <Sequence from={SCENES.s2.from} durationInFrames={SCENES.s2.dur} name={SCENES.s2.name}>
        <Scene2 />
      </Sequence>
      <Sequence from={SCENES.s3.from} durationInFrames={SCENES.s3.dur} name={SCENES.s3.name}>
        <Scene3 />
      </Sequence>
      <Sequence from={SCENES.s4.from} durationInFrames={SCENES.s4.dur} name={SCENES.s4.name}>
        <Scene4 />
      </Sequence>

      {/* hard-cut glitch bursts on every scene boundary */}
      {[SCENES.s2.from, SCENES.s3.from, SCENES.s4.from].map((at) => (
        <Sequence key={at} from={at - 3} durationInFrames={20} name={`cut@${at}`}>
          <CutGlitch at={3} />
        </Sequence>
      ))}
    </AbsoluteFill>
  </EnergyProvider>
);
