import React, { createContext, useContext, useMemo } from "react";
import { staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { useAudioData, visualizeAudio } from "@remotion/media-utils";

/** Narration track. Replace public/voice.mp3 with the real voiceover. */
export const VOICE_SRC = staticFile("voice.mp3");

export type Energy = { level: number; bass: number; flux: number };

const EnergyContext = createContext<Energy>({ level: 0, bass: 0, flux: 0 });
export const useEnergy = (): Energy => useContext<Energy>(EnergyContext);

/**
 * Reads the narration waveform once, exposes per-frame loudness (level/bass)
 * and an onset detector (flux) so loud narrative cues trigger glitch shakes.
 * Must be mounted OUTSIDE any <Sequence> so frames are global.
 */
export const EnergyProvider: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const audioData = useAudioData(VOICE_SRC);

  const value = useMemo<Energy>(() => {
    if (!audioData) return { level: 0, bass: 0, flux: 0 };
    const sample = (f: number) => {
      const v = visualizeAudio({ fps, frame: Math.max(0, f), audioData, numberOfSamples: 32 });
      const bass = (v[0] + v[1] + v[2] + v[3]) / 4;
      const level = v.reduce((a, b) => a + b, 0) / v.length;
      return { level, bass };
    };
    const now = sample(frame);
    const prev = (sample(frame - 2).level + sample(frame - 4).level + sample(frame - 6).level) / 3;
    return {
      level: Math.min(1, now.level * 3),
      bass: Math.min(1, now.bass * 3),
      flux: Math.min(1, Math.max(0, (now.level - prev) * 7)),
    };
  }, [audioData, frame, fps]);

  return <EnergyContext.Provider value={value}>{children}</EnergyContext.Provider>;
};
