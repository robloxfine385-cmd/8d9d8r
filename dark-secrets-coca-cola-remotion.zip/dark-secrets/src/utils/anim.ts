import { Easing, interpolate, random } from "remotion";

export const EASE = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  in: Easing.bezier(0.7, 0, 0.84, 0),
  inOut: Easing.bezier(0.83, 0, 0.17, 1),
  gravity: Easing.in(Easing.quad),
  lin: Easing.linear,
};

/** interpolate() with both extrapolations clamped (a < b required). */
export const ramp = (
  frame: number,
  a: number,
  b: number,
  from: number,
  to: number,
  easing: (t: number) => number = EASE.out,
) =>
  interpolate(frame, [a, b], [from, to], {
    easing,
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

/** 1 -> 0 decay envelope after the most recent cue frame (0 before any cue). */
export const impact = (frame: number, cues: readonly number[], len = 20) => {
  let m = 0;
  for (const c of cues) {
    const age = frame - c;
    if (age < 0 || age > len) continue;
    const v = interpolate(age, [0, len], [1, 0], {
      easing: EASE.out,
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    });
    if (v > m) m = v;
  }
  return m;
};

/** deterministic per-frame noise in [-1, 1] */
export const jitter = (key: string, frame: number) => random(`${key}-${frame}`) * 2 - 1;

export const clamp01 = (v: number) => Math.max(0, Math.min(1, v));
