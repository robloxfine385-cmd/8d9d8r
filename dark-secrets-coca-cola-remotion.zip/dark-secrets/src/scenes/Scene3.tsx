import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C, FONT } from "../constants/theme";
import { CUES, DIALOGS, wordCount, wordFrames } from "../constants/dialogs";
import { EASE, impact, ramp } from "../utils/anim";
import { SceneFX } from "../components/GlitchFX";
import { Burst, BurstCanvas, BRollOverlay, FizzCanvas, SmokeCanvas, StrobeFlare } from "../components/BRollOverlay";
import { KineticGlitchText } from "../components/KineticGlitchText";
import { Sfx } from "../components/Sfx";

// ---- layout (scene px) ----
const TANK = { x: 110, y: 170, w: 790, h: 630 };
const PAD = 14;
const SURFACE = 360; // soda surface y
const IW = TANK.w - PAD * 2; // interior width
const IX = TANK.x + PAD;
const CUBE_X = [260, 520, 380, 700, 300, 610, 450, 760, 340, 560];
const IMP = CUBE_X.map((_, i) => 100 + i * 36); // impact frames
const FALL = 22;

const TEXT_START = 60;
const TEXT_PER = 6;
const OVERLAY_N = wordCount(DIALOGS.s3.overlay);
const ALL_CUES = [...CUES.s3, ...IMP, ...wordFrames(OVERLAY_N, TEXT_START, TEXT_PER)];

const clampOpt = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

// ------------------------------------------------------------------ sugar cube (CSS 3D)
const Cube3D: React.FC<{ size: number; rx: number; ry: number }> = ({ size, rx, ry }) => {
  const face = (tf: string, shade: number): React.CSSProperties => ({
    position: "absolute",
    width: size,
    height: size,
    transform: tf,
    backgroundColor: "#efeae0",
    backgroundImage: "radial-gradient(rgba(150,140,120,0.55) 1px, transparent 1.6px)",
    backgroundSize: "6px 6px",
    boxShadow: `inset 0 0 ${size * 0.25}px rgba(120,105,80,0.55)`,
    filter: `brightness(${shade})`,
    border: "1px solid rgba(255,255,255,0.7)",
  });
  const h = size / 2;
  return (
    <div style={{ width: size, height: size, perspective: 700 }}>
      <div style={{ position: "relative", width: size, height: size, transformStyle: "preserve-3d", transform: `rotateX(${rx}deg) rotateY(${ry}deg)` }}>
        <div style={face(`translateZ(${h}px)`, 1)} />
        <div style={face(`rotateY(180deg) translateZ(${h}px)`, 0.7)} />
        <div style={face(`rotateY(90deg) translateZ(${h}px)`, 0.85)} />
        <div style={face(`rotateY(-90deg) translateZ(${h}px)`, 0.78)} />
        <div style={face(`rotateX(90deg) translateZ(${h}px)`, 1.1)} />
        <div style={face(`rotateX(-90deg) translateZ(${h}px)`, 0.6)} />
      </div>
    </div>
  );
};

const surfacePath = (frame: number) => {
  const pts: string[] = [];
  for (let x = 0; x <= IW; x += 6) {
    let y = 0;
    for (let i = 0; i < IMP.length; i++) {
      const age = frame - IMP[i];
      if (age < 0 || age > 110) continue;
      const cx = CUBE_X[i] - IX;
      const dist = Math.abs(x - cx);
      y += 24 * Math.exp(-age / 20) * Math.cos(dist * 0.06 - age * 0.45) * Math.exp(-dist / 260);
    }
    pts.push(`${x} ${y.toFixed(2)}`);
  }
  return pts;
};

const SodaTank: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1, spring({ frame, fps, config: { damping: 18, stiffness: 80, mass: 1 } }));
  const wave = surfacePath(frame);
  const fluidH = TANK.y + TANK.h - PAD - SURFACE;
  const top = wave.map((p, i) => (i === 0 ? `M ${p}` : `L ${p}`)).join(" ");
  const fluid = `${top} L ${IW} ${fluidH} L 0 ${fluidH} Z`;
  const count = IMP.filter((f) => frame >= f).length;
  const foam = ramp(frame, 100, 460, 6, 48, EASE.out);
  const fizz = ramp(frame, 60, 460, 0.35, 1, EASE.out);

  return (
    <div style={{ position: "absolute", left: TANK.x, top: TANK.y, width: TANK.w, height: TANK.h, opacity: enter, transform: `translateY(${(1 - enter) * 80}px)` }}>
      {/* glass */}
      <div style={{ position: "absolute", inset: 0, border: "4px solid rgba(255,255,255,0.28)", background: "linear-gradient(135deg, rgba(255,255,255,0.07), rgba(255,255,255,0.01))", boxShadow: "inset 0 0 70px rgba(0,0,0,0.7), 0 0 60px rgba(255,120,30,0.18)" }} />
      {/* ticker */}
      <div style={{ position: "absolute", left: 0, top: -64, display: "flex", alignItems: "baseline", gap: 16, fontFamily: FONT.latinHero }}>
        <span style={{ fontSize: 34, color: C.amber, letterSpacing: "0.12em" }}>SUGAR LOAD</span>
        <span style={{ fontSize: 64, color: C.white, lineHeight: 1 }}>
          {String(count).padStart(2, "0")}
          <span style={{ color: C.steel, fontSize: 40 }}> / 10 TSP</span>
        </span>
      </div>
      {/* fluid */}
      <svg width={IW} height={fluidH} style={{ position: "absolute", left: PAD, top: SURFACE - TANK.y, overflow: "visible" }}>
        <defs>
          <linearGradient id="sodaFluid" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#3a1a0a" stopOpacity={0.8} />
            <stop offset="1" stopColor="#050201" stopOpacity={0.96} />
          </linearGradient>
        </defs>
        <path d={fluid} fill="url(#sodaFluid)" />
        <path d={top} fill="none" stroke={C.amber} strokeWidth={3} opacity={0.85} style={{ filter: `drop-shadow(0 0 10px ${C.amber})` }} />
      </svg>
      <FizzCanvas width={IW} height={fluidH} count={150} color={[255, 190, 120]} seed="soda" pop intensity={fizz} style={{ left: PAD, top: SURFACE - TANK.y }} />
      <div style={{ position: "absolute", left: PAD, top: SURFACE - TANK.y - foam * 0.6, width: IW, height: foam, backgroundImage: "radial-gradient(ellipse at 20% 100%, rgba(255,235,200,0.85), transparent 40%), radial-gradient(ellipse at 55% 100%, rgba(255,225,185,0.8), transparent 38%), radial-gradient(ellipse at 88% 100%, rgba(255,235,200,0.85), transparent 40%)", opacity: 0.8 }} />
      <div style={{ position: "absolute", left: 28, top: 20, width: 12, height: TANK.h - 40, background: "linear-gradient(180deg, rgba(255,255,255,0.35), rgba(255,255,255,0))" }} />
    </div>
  );
};

const SugarCubes: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <>
      {IMP.map((imp, i) => {
        const age = frame - (imp - FALL);
        if (age < -1 || age > 130) return null;
        const falling = ramp(age, 0, FALL, -160, SURFACE - 34, EASE.gravity);
        const sink = ramp(age - FALL, 0, 70, 0, 150, EASE.out);
        const y = age < FALL ? falling : SURFACE - 34 + sink;
        const sc = ramp(age - FALL, 0, 80, 1, 0.5, EASE.out);
        const op = ramp(age - FALL, 30, 100, 1, 0, EASE.in);
        const rx = ramp(age, 0, 110, 20, 250 + i * 25, EASE.out);
        const ry = ramp(age, 0, 110, 30, -200 - i * 30, EASE.out);
        return (
          <div key={i} style={{ position: "absolute", left: CUBE_X[i] - 37, top: y - 37, opacity: op, transform: `scale(${sc})` }}>
            <Cube3D size={74} rx={rx} ry={ry} />
          </div>
        );
      })}
    </>
  );
};

const Ripples: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
      {IMP.map((imp, i) => {
        const age = frame - imp;
        if (age < 0 || age > 54) return null;
        const rx = ramp(age, 0, 54, 14, 230, EASE.out);
        return <ellipse key={i} cx={CUBE_X[i]} cy={SURFACE + 4} rx={rx} ry={rx * 0.17} fill="none" stroke={C.amber} strokeWidth={3} opacity={ramp(age, 0, 54, 0.9, 0, EASE.in)} />;
      })}
    </svg>
  );
};

// ------------------------------------------------------------------ cardiac monitor
const bpmAt = (f: number) =>
  interpolate(f, [0, 380, 440, 520, 700, 900], [72, 78, 156, 132, 126, 118], clampOpt);

const PHASE: number[] = (() => {
  const arr: number[] = [];
  let ph = 0;
  for (let f = 0; f < 900; f++) {
    arr.push(ph);
    ph += bpmAt(f) / 3600;
  }
  return arr;
})();

const g = (x: number, c: number, w: number, a: number) => a * Math.exp(-Math.pow((x - c) / w, 2));
const ecg = (x: number) =>
  g(x, 0.14, 0.025, 0.12) + g(x, 0.3, 0.008, -0.15) + g(x, 0.33, 0.01, 1) + g(x, 0.355, 0.01, -0.25) + g(x, 0.55, 0.04, 0.25);

const HeartMonitor: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1, spring({ frame: frame - 20, fps, config: { damping: 16, stiffness: 90, mass: 0.9 } }));
  const W = 740;
  const H = 150;
  const N = 150;
  const spike = ramp(frame, 380, 440, 1, 1.45, EASE.out);
  const bpm = Math.round(bpmAt(frame));
  const col = {
    r: Math.round(ramp(bpm, 80, 130, 57, 255, EASE.inOut)),
    g: Math.round(ramp(bpm, 80, 130, 255, 23, EASE.inOut)),
    b: Math.round(ramp(bpm, 80, 130, 20, 48, EASE.inOut)),
  };
  const stroke = `rgb(${col.r}, ${col.g}, ${col.b})`;
  const pts: string[] = [];
  let last = { x: 0, y: 0 };
  for (let i = 0; i < N; i++) {
    const fi = Math.min(899, Math.max(0, frame - (N - 1 - i) * 2));
    const ph = PHASE[fi] % 1;
    const x = (i / (N - 1)) * W;
    const y = H * 0.62 - ecg(ph) * spike * H * 0.5;
    pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
    last = { x, y };
  }
  const fr = PHASE[Math.min(899, frame)] % 1;
  const beat = ramp(fr, 0.3, 0.34, 0, 1, EASE.out) * (1 - ramp(fr, 0.34, 0.62, 0, 1, EASE.out));
  const insulin = ramp(frame, 380, 450, 0, 100, EASE.out);
  const warn = frame > 380 && frame < 640 ? ramp(frame % 24, 0, 12, 1, 0.2, EASE.out) : 0;

  return (
    <div style={{ position: "absolute", left: 1040, top: 70, width: 790, opacity: enter, transform: `translateX(${(1 - enter) * 140}px)`, background: "rgba(6,10,8,0.85)", border: `2px solid ${stroke}`, boxShadow: `0 0 40px rgba(${col.r},${col.g},${col.b},0.35)`, padding: "14px 24px 16px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div style={{ fontFamily: FONT.mono, fontWeight: 700, fontSize: 16, letterSpacing: "0.28em", color: stroke }}>CARDIAC MONITOR</div>
        <div style={{ fontFamily: FONT.latinHero, fontSize: 34, letterSpacing: "0.08em", color: C.red, opacity: warn }}>INSULIN SPIKE</div>
      </div>
      <div style={{ position: "relative", marginTop: 6, height: H, backgroundImage: "linear-gradient(rgba(57,255,20,0.12) 1px, transparent 1px), linear-gradient(90deg, rgba(57,255,20,0.12) 1px, transparent 1px)", backgroundSize: "30px 30px" }}>
        <svg width={W} height={H} style={{ position: "absolute", left: 0, top: 0, overflow: "visible", filter: `drop-shadow(0 0 8px ${stroke})` }}>
          <polyline points={pts.join(" ")} fill="none" stroke={stroke} strokeWidth={3.5} strokeLinejoin="round" />
          <circle cx={last.x} cy={last.y} r={6} fill="#fff" />
        </svg>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 22, marginTop: 8 }}>
        <svg viewBox="0 0 24 24" width={56} height={56} style={{ transform: `scale(${1 + 0.28 * beat})`, filter: `drop-shadow(0 0 ${8 + 16 * beat}px ${C.red})` }}>
          <path d="M12 21s-7.5-4.6-10-9.3C.3 8.2 2.4 4 6.3 4c2.1 0 3.9 1.1 5.7 3.2C13.8 5.1 15.6 4 17.7 4c3.9 0 6 4.2 4.3 7.7C19.5 16.4 12 21 12 21z" fill={C.red} />
        </svg>
        <div style={{ fontFamily: FONT.latinHero, fontSize: 78, lineHeight: 1, color: C.white }}>
          {bpm}
          <span style={{ fontSize: 30, color: C.steel, letterSpacing: "0.1em" }}> BPM</span>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: FONT.mono, fontSize: 14, letterSpacing: "0.22em", color: C.steel }}>INSULIN {Math.round(insulin)}%</div>
          <div style={{ height: 12, background: "rgba(255,255,255,0.1)", marginTop: 4 }}>
            <div style={{ height: "100%", width: `${insulin}%`, background: `linear-gradient(90deg, ${C.toxic}, ${C.red})`, boxShadow: `0 0 12px ${C.red}` }} />
          </div>
        </div>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------ corrosive acid beaker + dissolving nail
const BEAKER = { x: 1040, y: 420, w: 790, h: 380 };
const GLASS = { x: 120, w: 540, top: 30, bottom: 370 };
const ACID_SURFACE = 130;
const NAIL = { x: 390, headY: 20, tipY: 330, hw: 8 };

const AcidBeaker: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1, spring({ frame: frame - 470, fps, config: { damping: 14, stiffness: 100, mass: 0.9 } }));
  const dip = ramp(frame, 490, 550, -260, 0, EASE.out);
  const p = ramp(frame, 560, 870, 0, 1, EASE.inOut);
  const bubble = ramp(frame, 480, 700, 0.3, 1, EASE.out);
  const env = impact(frame, [480, 560, 700, 860], 18);

  const N = 30;
  const rows = Array.from({ length: N + 1 }).map((_, j) => {
    const t = j / N;
    const y = NAIL.headY + 6 + (NAIL.tipY - NAIL.headY - 6) * t;
    const yw = y + dip;
    const d = Math.min(1, Math.max(0, (yw - ACID_SURFACE) / (NAIL.tipY + dip - ACID_SURFACE)));
    const n = ((Math.sin(j * 12.9898) * 43758.5453) % 1 + 1) % 1;
    const e = Math.min(1, Math.max(0, p * 1.5 + d * 0.5 - 0.5 + (n - 0.5) * 0.25));
    const w = yw > ACID_SURFACE ? NAIL.hw * (1 - e) : NAIL.hw * (1 - Math.min(1, Math.max(0, p * 1.2 - 0.3 + (n - 0.5) * 0.2)) * 0.7);
    return { y, w: Math.max(0, w) };
  });
  const left = rows.map((r) => `${NAIL.x - r.w},${r.y}`);
  const right = rows
    .slice()
    .reverse()
    .map((r) => `${NAIL.x + r.w},${r.y}`);
  const poly = [...left, ...right].join(" ");
  const cleanY = ramp(p, 0, 0.6, NAIL.tipY, ACID_SURFACE - dip, EASE.inOut); // nail-local y of the clean front

  return (
    <div style={{ position: "absolute", left: BEAKER.x, top: BEAKER.y, width: BEAKER.w, height: BEAKER.h, opacity: enter, transform: `translateY(${(1 - enter) * 100}px)` }}>
      {/* beaker glass */}
      <div style={{ position: "absolute", left: GLASS.x, top: GLASS.top, width: GLASS.w, height: GLASS.bottom - GLASS.top, border: "4px solid rgba(255,255,255,0.3)", borderTop: "none", borderRadius: "0 0 40px 40px", background: "linear-gradient(135deg, rgba(255,255,255,0.08), rgba(255,255,255,0))", boxShadow: "inset 0 0 50px rgba(0,0,0,0.6)" }} />
      {/* acid */}
      <div style={{ position: "absolute", left: GLASS.x + 4, top: ACID_SURFACE, width: GLASS.w - 8, height: GLASS.bottom - ACID_SURFACE - 4, borderRadius: "0 0 36px 36px", background: "linear-gradient(180deg, rgba(57,255,20,0.78), rgba(8,80,8,0.95))", boxShadow: `0 0 ${70 + 50 * env}px rgba(57,255,20,0.55)` }} />
      <div style={{ position: "absolute", left: GLASS.x + 4, top: ACID_SURFACE - 3, width: GLASS.w - 8, height: 6, background: "#caffc0", boxShadow: `0 0 18px ${C.toxic}` }} />
      <FizzCanvas width={GLASS.w - 8} height={GLASS.bottom - ACID_SURFACE - 4} count={150} color={[160, 255, 120]} speed={1.5} seed="acid" pop intensity={bubble} style={{ left: GLASS.x + 4, top: ACID_SURFACE }} />
      <SmokeCanvas width={GLASS.w} height={240} count={50} color={[120, 255, 90]} spread={300} size={60} alpha={0.2} rate={1.4} rise={1} seed="fumes" style={{ left: GLASS.x, top: ACID_SURFACE - 230, opacity: bubble }} />
      {/* nail */}
      <svg width={BEAKER.w} height={BEAKER.h} style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
        <defs>
          <linearGradient id="steelNail" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#6d7886" />
            <stop offset="0.5" stopColor="#eef2f7" />
            <stop offset="1" stopColor="#5a6573" />
          </linearGradient>
          <linearGradient id="rustNail" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#5a2208" />
            <stop offset="0.5" stopColor="#b9531c" />
            <stop offset="1" stopColor="#4a1c06" />
          </linearGradient>
          <clipPath id="rustClip">
            <rect x={NAIL.x - 30} y={-40} width={60} height={Math.max(0, cleanY + 40)} />
          </clipPath>
        </defs>
        <g transform={`translate(0 ${dip})`}>
          <ellipse cx={NAIL.x} cy={NAIL.headY} rx={30} ry={8} fill="url(#steelNail)" />
        </g>
        <polygon points={poly} transform={`translate(0 ${dip})`} fill="url(#steelNail)" />
        <polygon points={poly} transform={`translate(0 ${dip})`} fill="url(#rustNail)" clipPath="url(#rustClip)" />
      </svg>
      {/* labels */}
      <div style={{ position: "absolute", left: 680, top: 140, fontFamily: FONT.latinHero, color: C.toxic, fontSize: 46, lineHeight: 1.05, textShadow: `0 0 18px ${C.toxic}` }}>
        H<sub style={{ fontSize: 26 }}>3</sub>PO<sub style={{ fontSize: 26 }}>4</sub>
        <div style={{ fontFamily: FONT.mono, fontSize: 16, letterSpacing: "0.2em", color: C.white }}>pH ~ 2.5 (COLA)</div>
        <div style={{ fontFamily: FONT.mono, fontSize: 16, letterSpacing: "0.2em", color: C.steel }}>RUST REMOVAL {Math.round(ramp(p, 0, 0.6, 0, 100, EASE.inOut))}%</div>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------ warning tags
const WarnTag: React.FC<{ x: number; y: number; at: number; color: string }> = ({ x, y, at, color }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame < at) return null;
  const p = spring({ frame: frame - at, fps, config: { damping: 8, stiffness: 240, mass: 0.6 } });
  const pulse = ramp((frame - at) % 30, 0, 15, 1, 0.45, EASE.out);
  return (
    <div style={{ position: "absolute", left: x, top: y, width: 110, height: 98, transform: `scale(${Math.max(0, p)}) rotate(${(1 - p) * 20}deg)`, filter: `drop-shadow(0 0 ${20 * pulse}px ${color})` }}>
      <div style={{ position: "absolute", inset: 0, background: color, clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} />
      <div style={{ position: "absolute", left: 8, top: 14, right: 8, bottom: 8, background: C.ink, clipPath: "polygon(50% 0, 100% 100%, 0 100%)" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 30, textAlign: "center", fontFamily: FONT.latinHero, fontSize: 62, color, lineHeight: 1 }}>!</div>
    </div>
  );
};

export const Scene3: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const chapter = Math.min(1, spring({ frame: frame - 8, fps, config: { damping: 16, stiffness: 120, mass: 0.7 } }));

  const bursts: Burst[] = IMP.flatMap((at, i) => [
    { at, x: CUBE_X[i], y: SURFACE, count: 70, speed: 13, spread: 0.75, gravity: 0.55, life: 48, color: [255, 190, 110], size: 4.5, seed: `sp${i}` },
    { at, x: CUBE_X[i], y: SURFACE, count: 34, speed: 8, spread: 1.1, gravity: 0.5, life: 38, color: [255, 245, 230], size: 3, seed: `sw${i}` },
  ]);
  const acidBursts: Burst[] = [480, 560, 700, 860].map((at, i) => ({
    at, x: BEAKER.x + GLASS.x + GLASS.w / 2, y: BEAKER.y + ACID_SURFACE, count: 40, speed: 9, spread: 0.8, gravity: 0.45, life: 40, color: [120, 255, 80], size: 3.5, seed: `ac${i}`,
  }));

  return (
    <AbsoluteFill style={{ backgroundColor: C.bg }}>
      <SceneFX id="ca-s3" cues={ALL_CUES} base={0.03} flashColor="#ffe6c0">
        <AbsoluteFill style={{ background: "radial-gradient(ellipse at 35% 45%, #1d0d06 0%, #080504 60%, #030202 100%)" }} />
        <SodaTank />
        <SugarCubes />
        <Ripples />
        <BurstCanvas width={1920} height={1080} bursts={[...bursts, ...acidBursts]} style={{ left: 0, top: 0 }} />
        <HeartMonitor />
        <AcidBeaker />
        <WarnTag x={925} y={190} at={440} color={C.amber} />
        <WarnTag x={925} y={430} at={560} color={C.toxic} />

        {/* chapter tag */}
        <div style={{ position: "absolute", left: 110, top: 22, opacity: chapter, transform: `translateX(${(1 - chapter) * -120}px)` }}>
          <div style={{ fontFamily: FONT.mono, fontWeight: 700, fontSize: 16, letterSpacing: "0.3em", color: C.amber }}>CHAPTER 03</div>
          <div style={{ fontFamily: FONT.bengaliHero, fontWeight: 900, fontSize: 40, color: C.white, lineHeight: 1.3 }}>{DIALOGS.s3.chapter}</div>
        </div>

        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 300, background: "linear-gradient(180deg, transparent, rgba(0,0,0,0.88))" }} />
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 40, display: "flex", justifyContent: "center" }}>
          <KineticGlitchText
            text={DIALOGS.s3.overlay}
            startFrame={TEXT_START}
            perWord={TEXT_PER}
            fontSize={100}
            accent={C.amber}
            highlight={[0, 1, 2, 4, 5]}
            emphasis={[
              { frame: 440, indices: [0, 1, 2] },
              { frame: 560, indices: [4, 5] },
            ]}
            glitchFrames={[440, 480, 560, 700, 860]}
          />
        </div>
        <StrobeFlare cues={[440, 560]} x={1500} y={260} color="#ff3b30" />
        <StrobeFlare cues={[480, 700, 860]} x={1500} y={640} color="#39ff14" />
      </SceneFX>
      <BRollOverlay tint={C.amber} />

      {IMP.map((c, i) => (
        <React.Fragment key={c}>
          <Sfx name="impact" at={c - 1} volume={0.55} />
          <Sfx name="splash" at={c} volume={0.55} />
          <Sfx name="tick" at={c} volume={0.3} />
          {i === 0 ? <Sfx name="whoosh" at={c - FALL} volume={0.3} /> : null}
        </React.Fragment>
      ))}
      <Sfx name="heartbeat" at={380} volume={0.6} />
      <Sfx name="heartbeat" at={436} volume={0.7} />
      <Sfx name="heartbeat" at={492} volume={0.7} />
      <Sfx name="glitch" at={438} volume={0.55} />
      <Sfx name="riser" at={410} volume={0.45} />
      <Sfx name="impact" at={440} volume={0.85} />
      <Sfx name="impact" at={480} volume={0.8} />
      <Sfx name="sizzle" at={486} volume={0.5} />
      <Sfx name="impact" at={560} volume={0.85} />
      <Sfx name="sizzle" at={640} volume={0.5} />
      <Sfx name="impact" at={700} volume={0.7} />
      <Sfx name="sizzle" at={780} volume={0.5} />
      <Sfx name="impact" at={860} volume={0.75} />
    </AbsoluteFill>
  );
};
