import React, { useMemo } from "react";
import { AbsoluteFill, random, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C, FONT } from "../constants/theme";
import { CUES, DIALOGS, wordCount, wordFrames } from "../constants/dialogs";
import { EASE, impact, ramp } from "../utils/anim";
import { SceneFX } from "../components/GlitchFX";
import { BRollOverlay, SmokeCanvas, StrobeFlare } from "../components/BRollOverlay";
import { KineticGlitchText } from "../components/KineticGlitchText";
import { Sfx } from "../components/Sfx";

const TEXT_START = 330;
const TEXT_PER = 7;
const WORD_CUES = wordFrames(wordCount(DIALOGS.s2.overlay), TEXT_START, TEXT_PER);
const ALL_CUES = [...CUES.s2, ...WORD_CUES];
const INK = "#2a1c0c";

// ------------------------------------------------------------------ dark retro pharmacy lab
const Pharmacy: React.FC = () => {
  const frame = useCurrentFrame();
  const drift = ramp(frame, 0, 720, 0, -90, EASE.inOut);
  const jars = useMemo(() => {
    const out: { s: number; x: number; w: number; h: number; hue: number; key: string }[] = [];
    for (let s = 0; s < 3; s++) {
      let x = -30;
      let i = 0;
      while (x < 2100) {
        const w = 70 + random(`jw${s}-${i}`) * 50;
        const h = 100 + random(`jh${s}-${i}`) * 80;
        out.push({ s, x, w, h, hue: Math.floor(random(`jc${s}-${i}`) * 3), key: `${s}-${i}` });
        x += w + 18 + random(`jg${s}-${i}`) * 22;
        i++;
      }
    }
    return out;
  }, []);
  const liquids = [
    "linear-gradient(180deg, rgba(255,176,32,0.7), rgba(130,60,8,0.9))",
    "linear-gradient(180deg, rgba(120,170,60,0.55), rgba(40,70,20,0.9))",
    "linear-gradient(180deg, rgba(160,60,40,0.6), rgba(70,20,14,0.9))",
  ];
  const lamp = (cx: number, cy: number, k: number) => (
    <div
      key={k}
      style={{
        position: "absolute",
        left: cx - 260,
        top: cy - 260,
        width: 520,
        height: 520,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(255,170,60,0.5), transparent 65%)",
        opacity: 0.6 + 0.3 * random(`lamp${k}-${Math.floor(frame / 4)}`),
      }}
    />
  );
  return (
    <AbsoluteFill style={{ background: "linear-gradient(180deg, #1c1008, #090503)", filter: "blur(2.5px) brightness(0.75)" }}>
      <div style={{ position: "absolute", inset: 0, transform: `translateX(${drift}px)` }}>
        {[0, 1, 2].map((s) => {
          const y = 290 + s * 290;
          return (
            <React.Fragment key={s}>
              {jars
                .filter((j) => j.s === s)
                .map((j) => (
                  <div key={j.key} style={{ position: "absolute", left: j.x, top: y - j.h, width: j.w, height: j.h }}>
                    <div style={{ position: "absolute", left: j.w * 0.2, top: -12, width: j.w * 0.6, height: 14, background: "linear-gradient(180deg,#7a5a2a,#3a2a12)", borderRadius: 3 }} />
                    <div style={{ position: "absolute", inset: 0, background: liquids[j.hue], borderRadius: "10px 10px 6px 6px", border: "2px solid rgba(255,220,160,0.25)" }} />
                    <div style={{ position: "absolute", left: j.w * 0.18, top: j.h * 0.32, width: j.w * 0.64, height: j.h * 0.3, background: "#d8c9a4", opacity: 0.85 }} />
                    <div style={{ position: "absolute", left: 8, top: 8, width: 6, height: j.h - 16, background: "rgba(255,255,255,0.22)" }} />
                  </div>
                ))}
              <div style={{ position: "absolute", left: 0, top: y, width: 2200, height: 16, background: "linear-gradient(180deg,#5a3d1c,#24160a)" }} />
            </React.Fragment>
          );
        })}
      </div>
      {lamp(300, 140, 0)}
      {lamp(1000, 110, 1)}
      {lamp(1650, 160, 2)}
    </AbsoluteFill>
  );
};

// ------------------------------------------------------------------ laboratory microscope (procedural SVG)
const Microscope: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1, spring({ frame: frame - 60, fps, config: { damping: 18, stiffness: 70, mass: 1.1 } }));
  const env = impact(frame, ALL_CUES, 14);
  return (
    <svg
      viewBox="0 0 200 260"
      width={250}
      height={325}
      style={{ position: "absolute", left: 70, top: 640, opacity: enter * 0.9, transform: `translateY(${(1 - enter) * 120}px)`, filter: `drop-shadow(0 0 ${14 + 30 * env}px rgba(255,176,32,0.7))` }}
    >
      <defs>
        <linearGradient id="brass" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#4a3412" />
          <stop offset="0.5" stopColor="#d9a64a" />
          <stop offset="1" stopColor="#3a2810" />
        </linearGradient>
      </defs>
      <rect x="25" y="232" width="150" height="20" rx="6" fill="url(#brass)" />
      <path d="M 140 232 C 196 204, 196 96, 122 54" fill="none" stroke="url(#brass)" strokeWidth="18" strokeLinecap="round" />
      <g transform="rotate(-24 104 70)">
        <rect x="90" y="6" width="26" height="118" rx="6" fill="url(#brass)" />
        <rect x="94" y="0" width="18" height="12" fill="#2a1d0a" />
        <rect x="96" y="124" width="14" height="22" fill="#2a1d0a" />
        <circle cx="103" cy="150" r="7" fill="#fff6dc" opacity={0.6 + 0.4 * env} />
      </g>
      <rect x="50" y="170" width="96" height="8" rx="2" fill="url(#brass)" />
      <circle cx="72" cy="196" r="9" fill="url(#brass)" />
      <circle cx="46" cy="198" r="6" fill="url(#brass)" />
      <polygon points="82,214 102,178 122,214" fill="rgba(255,230,160,0.25)" />
    </svg>
  );
};

// ------------------------------------------------------------------ floating 1886 newspaper clippings
const torn = (seed: number) => {
  const pts: string[] = [];
  const j = (k: number) => (random(`torn${seed}-${k}`) - 0.5) * 3.2;
  for (let i = 0; i <= 8; i++) pts.push(`${(i / 8) * 100 + (i % 8 ? j(i) : 0)}% ${1 + j(i + 20)}%`);
  for (let i = 1; i <= 5; i++) pts.push(`${99 + j(i + 40)}% ${(i / 6) * 100}%`);
  for (let i = 8; i >= 0; i--) pts.push(`${(i / 8) * 100 + (i % 8 ? j(i + 60) : 0)}% ${99 + j(i + 80)}%`);
  for (let i = 5; i >= 1; i--) pts.push(`${1 + j(i + 100)}% ${(i / 6) * 100}%`);
  return pts.join(", ");
};

type ClipProps = {
  x: number;
  y: number;
  w: number;
  h: number;
  rot: number;
  depth: number;
  head: string;
  sub: string;
  seed: number;
  hero?: boolean;
};

const Clipping: React.FC<ClipProps> = ({ x, y, w, h, rot, depth, head, sub, seed, hero }) => {
  const frame = useCurrentFrame();
  const dy = Math.sin(frame / (60 + seed * 9) + seed) * 10 * depth;
  const dr = Math.sin(frame / (90 + seed * 7) + seed) * 1.2;
  const poly = useMemo(() => torn(seed), [seed]);
  const lines = "repeating-linear-gradient(180deg, rgba(42,28,12,0.7) 0px, rgba(42,28,12,0.7) 2px, transparent 2px, transparent 9px)";
  return (
    <div style={{ position: "absolute", left: x, top: y, width: w, height: h, transform: `translateY(${dy}px) rotate(${rot + dr}deg)`, filter: "drop-shadow(0 22px 28px rgba(0,0,0,0.75))" }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          clipPath: `polygon(${poly})`,
          background: "linear-gradient(135deg, #e2d0a2, #c8ae78 60%, #a98a52)",
          color: INK,
          padding: `${h * 0.04}px ${w * 0.05}px`,
        }}
      >
        <div style={{ fontFamily: FONT.serif, fontWeight: 900, fontSize: w * 0.05, letterSpacing: "0.12em", textAlign: "center", borderBottom: `4px double ${INK}`, paddingBottom: 4 }}>
          THE ATLANTA DAILY CHRONICLE
        </div>
        <div style={{ fontFamily: FONT.serif, fontWeight: 700, fontSize: w * 0.028, letterSpacing: "0.18em", textAlign: "center", margin: "6px 0" }}>{sub}</div>
        {hero ? (
          <div style={{ fontFamily: FONT.serif, fontWeight: 900, fontSize: h * 0.38, lineHeight: 1, textAlign: "center", letterSpacing: "0.02em" }}>1886</div>
        ) : null}
        <div style={{ fontFamily: FONT.serif, fontWeight: 900, fontSize: hero ? w * 0.05 : w * 0.075, lineHeight: 1.06, textTransform: "uppercase", textAlign: "center", marginTop: hero ? 4 : 8 }}>{head}</div>
        <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
          <div style={{ width: "36%", height: h * (hero ? 0.2 : 0.26), backgroundImage: "radial-gradient(circle, rgba(42,28,12,0.85) 1.6px, transparent 2.2px)", backgroundSize: "6px 6px", backgroundColor: "#b99c64", border: `2px solid ${INK}` }} />
          <div style={{ flex: 1, height: h * (hero ? 0.2 : 0.26), backgroundImage: lines }} />
          <div style={{ flex: 1, height: h * (hero ? 0.2 : 0.26), backgroundImage: lines }} />
        </div>
        <div style={{ marginTop: 10, height: h * 0.14, backgroundImage: lines }} />
      </div>
    </div>
  );
};

const CLIPS: ClipProps[] = [
  { x: 110, y: 80, w: 480, h: 340, rot: -9, depth: 0.6, head: "New brain tonic on sale at Atlanta pharmacy", sub: "ATLANTA · MAY 1886", seed: 1 },
  { x: 1280, y: 60, w: 520, h: 360, rot: 7, depth: 0.8, head: "Coca leaf extract: cure for nerves, says druggist", sub: "VOL. XXII · 1886", seed: 2 },
  { x: 30, y: 600, w: 460, h: 330, rot: 6, depth: 1.0, head: "Doctors debate the new coca tonics", sub: "LOCAL NEWS · 1886", seed: 3 },
  { x: 1400, y: 590, w: 500, h: 340, rot: -6, depth: 0.9, head: "Sold at the fountain: five cents a glass", sub: "ATLANTA · 1886", seed: 4 },
  { x: 620, y: 30, w: 420, h: 300, rot: 4, depth: 0.5, head: "The pharmacist and his secret syrup", sub: "SPECIAL REPORT", seed: 5 },
  { x: 1000, y: 720, w: 440, h: 300, rot: -3, depth: 0.7, head: "Tonic or poison? the town decides", sub: "EDITORIAL · 1886", seed: 6 },
  { x: 570, y: 250, w: 820, h: 560, rot: -2, depth: 0.3, head: "Pharmacist's new 'coca' tonic sparks town talk", sub: "ATLANTA · MAY 1886", seed: 7, hero: true },
];

const NewspaperWall: React.FC = () => {
  const frame = useCurrentFrame();
  const zoomIn = ramp(frame, 40, 250, 1, 3.2, EASE.inOut);
  const zoomOut = ramp(frame, 262, 332, 3.2, 1.05, EASE.out);
  const zoom = frame < 260 ? zoomIn : zoomOut;
  const blur = ramp(frame, 262, 300, 0, 7, EASE.out);
  const dim = ramp(frame, 262, 332, 1, 0.26, EASE.out);
  return (
    <AbsoluteFill style={{ filter: `sepia(0.85) contrast(1.12)${blur > 0.1 ? ` blur(${blur}px)` : ""}`, opacity: dim }}>
      <div style={{ position: "absolute", inset: 0, transformOrigin: "980px 440px", transform: `scale(${zoom})` }}>
        {CLIPS.map((c) => (
          <Clipping key={c.seed} {...c} />
        ))}
      </div>
    </AbsoluteFill>
  );
};

// ------------------------------------------------------------------ amber coca leaf + molecular bonds
const LEAF = "M150 8 C 232 70, 268 190, 232 290 C 212 345, 180 385, 150 412 C 120 385, 88 345, 68 290 C 32 190, 68 70, 150 8 Z";

const CocaLeaf: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1.08, spring({ frame: frame - 290, fps, config: { damping: 10, stiffness: 110, mass: 0.9 } }));
  const env = impact(frame, [300, 540, 640], 24);
  const rot = ramp(frame, 290, 720, -8, 8, EASE.inOut);
  const veins = Array.from({ length: 7 }).map((_, i) => {
    const y = 70 + i * 44;
    const hw = 92 * Math.pow(Math.sin((Math.PI * (y - 8)) / 404), 0.9);
    const p = ramp(frame, 296 + i * 3, 336 + i * 3, 0, 1, EASE.out);
    return { y, hw, p };
  });
  if (frame < 288) return null;
  return (
    <svg
      viewBox="0 0 300 420"
      width={380}
      height={532}
      style={{
        position: "absolute",
        left: 770,
        top: 160,
        transform: `rotate(${rot}deg) scale(${Math.max(0, enter)})`,
        filter: `drop-shadow(0 0 ${28 + 40 * env}px rgba(255,160,20,0.9))`,
      }}
    >
      <defs>
        <linearGradient id="leafFill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="rgba(255,176,32,0.65)" />
          <stop offset="1" stopColor="rgba(130,60,0,0.18)" />
        </linearGradient>
      </defs>
      <path d={LEAF} fill="url(#leafFill)" stroke={C.amber} strokeWidth={3} />
      <path d="M150 16 L150 404" stroke={C.amber} strokeWidth={3} opacity={0.8} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ramp(frame, 292, 340, 0, 1, EASE.out)} />
      {veins.map((v, i) => (
        <g key={i} fill="none" stroke={C.amber} strokeWidth={2.2} opacity={0.65}>
          <path d={`M150 ${v.y + 14} Q ${150 + v.hw * 0.5} ${v.y + 10} ${150 + v.hw * 0.9} ${v.y - 28}`} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - v.p} />
          <path d={`M150 ${v.y + 14} Q ${150 - v.hw * 0.5} ${v.y + 10} ${150 - v.hw * 0.9} ${v.y - 28}`} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - v.p} />
        </g>
      ))}
    </svg>
  );
};

const Molecule: React.FC<{ x: number; y: number; size: number; start: number; seed: number }> = ({ x, y, size, start, seed }) => {
  const frame = useCurrentFrame();
  const rot = ramp(frame, start, start + 480, 0, 160 * (seed % 2 ? 1 : -1), EASE.lin);
  const fy = Math.sin(frame / 50 + seed) * 14;
  const appear = ramp(frame, start, start + 20, 0, 1, EASE.out);
  const ring = Array.from({ length: 6 }).map((_, k) => {
    const a = ((60 * k - 90) * Math.PI) / 180;
    return { x: 150 + Math.cos(a) * 70, y: 150 + Math.sin(a) * 70 };
  });
  const chain = [
    { x: 150, y: 80 },
    { x: 150, y: 36 },
    { x: 206, y: 8 },
  ];
  const bonds: { x1: number; y1: number; x2: number; y2: number }[] = [];
  for (let k = 0; k < 6; k++) bonds.push({ x1: ring[k].x, y1: ring[k].y, x2: ring[(k + 1) % 6].x, y2: ring[(k + 1) % 6].y });
  bonds.push({ x1: chain[0].x, y1: chain[0].y, x2: chain[1].x, y2: chain[1].y });
  bonds.push({ x1: chain[1].x, y1: chain[1].y, x2: chain[2].x, y2: chain[2].y });
  const inner = [0, 2, 4].map((k) => {
    const a = ring[k];
    const b = ring[(k + 1) % 6];
    const f = (p: { x: number; y: number }) => ({ x: 150 + (p.x - 150) * 0.78, y: 150 + (p.y - 150) * 0.78 });
    return { a: f(a), b: f(b) };
  });
  const nodes = [...ring, chain[1], chain[2]];
  return (
    <svg
      viewBox="0 0 300 300"
      width={size}
      height={size}
      style={{ position: "absolute", left: x, top: y + fy, opacity: appear, transform: `rotate(${rot}deg)`, filter: `drop-shadow(0 0 12px ${C.amber})` }}
    >
      {bonds.map((b, i) => (
        <line key={i} x1={b.x1} y1={b.y1} x2={b.x2} y2={b.y2} stroke={C.amber} strokeWidth={4} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ramp(frame, start + i * 3, start + i * 3 + 24, 0, 1, EASE.out)} />
      ))}
      {inner.map((b, i) => (
        <line key={`i${i}`} x1={b.a.x} y1={b.a.y} x2={b.b.x} y2={b.b.y} stroke="#fff" strokeWidth={2.5} strokeLinecap="round" opacity={0.7} />
      ))}
      {nodes.map((n, i) => (
        <circle key={i} cx={n.x} cy={n.y} r={i > 5 ? 11 : 8} fill={i > 5 ? "#fff" : C.amber} />
      ))}
    </svg>
  );
};

// ------------------------------------------------------------------ BANNED rubber stamp
const BannedStamp: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - 540, fps, config: { damping: 9, stiffness: 240, mass: 0.7 } });
  if (frame < 540) return null;
  return (
    <div
      style={{
        position: "absolute",
        left: 1240,
        top: 330,
        transform: `rotate(-11deg) scale(${1 + (1 - p) * 2.6})`,
        opacity: ramp(frame, 540, 543, 0, 0.9, EASE.out),
        border: `10px solid ${C.red}`,
        padding: "4px 36px",
        fontFamily: FONT.latinHero,
        fontSize: 190,
        letterSpacing: "0.06em",
        lineHeight: 1,
        color: C.red,
        textShadow: `0 0 30px ${C.red}`,
        boxShadow: `0 0 40px ${C.red}, inset 0 0 40px rgba(255,23,48,0.35)`,
        mixBlendMode: "screen",
      }}
    >
      BANNED
    </div>
  );
};

export const Scene2: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const chapter = Math.min(1, spring({ frame: frame - 10, fps, config: { damping: 16, stiffness: 120, mass: 0.7 } }));
  const smoke = ramp(frame, 290, 360, 0, 1, EASE.out);

  return (
    <AbsoluteFill style={{ backgroundColor: C.bg }}>
      <SceneFX id="ca-s2" cues={ALL_CUES} base={0.06} flashColor="#ffe2b0">
        <Pharmacy />
        <Microscope />
        <NewspaperWall />

        <div style={{ position: "absolute", left: 360, top: 200, opacity: smoke }}>
          <SmokeCanvas width={1200} height={760} count={90} color={[255, 170, 50]} spread={560} size={80} alpha={0.2} rate={1.2} rise={0.95} seed="leaf-smoke" />
        </div>
        <div style={{ position: "absolute", left: 360, top: 200, opacity: smoke * 0.8 }}>
          <SmokeCanvas width={1200} height={760} count={50} color={[40, 30, 24]} spread={800} size={110} alpha={0.28} rate={0.8} rise={0.7} seed="dark-smoke" />
        </div>
        <CocaLeaf />
        <Molecule x={260} y={130} size={300} start={310} seed={1} />
        <Molecule x={1340} y={110} size={260} start={322} seed={2} />
        <Molecule x={1280} y={560} size={320} start={334} seed={3} />
        <Molecule x={330} y={540} size={230} start={346} seed={4} />
        <BannedStamp />

        {/* chapter tag + case-file label */}
        <div style={{ position: "absolute", left: 70, top: 56, opacity: chapter, transform: `translateX(${(1 - chapter) * -140}px)` }}>
          <div style={{ fontFamily: FONT.mono, fontWeight: 700, fontSize: 18, letterSpacing: "0.3em", color: C.amber }}>CHAPTER 02 · CASE FILE 1886</div>
          <div style={{ fontFamily: FONT.bengaliHero, fontWeight: 900, fontSize: 44, color: C.white, lineHeight: 1.4, textShadow: "0 4px 24px rgba(0,0,0,0.9)" }}>{DIALOGS.s2.chapter}</div>
        </div>

        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 380, background: "linear-gradient(180deg, transparent, rgba(0,0,0,0.85))" }} />
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 48, display: "flex", justifyContent: "center" }}>
          <KineticGlitchText
            text={DIALOGS.s2.overlay}
            startFrame={TEXT_START}
            perWord={TEXT_PER}
            fontSize={118}
            variant="stamp"
            accent={C.amber}
            highlight={[0, 3, 4]}
            glitchFrames={WORD_CUES}
          />
        </div>
        <StrobeFlare cues={[260, 300]} x={980} y={440} color="#ffb020" />
      </SceneFX>
      <BRollOverlay tint={C.amber} />

      <Sfx name="whoosh" at={38} volume={0.5} />
      <Sfx name="riser" at={170} volume={0.5} />
      {CUES.s2.map((c) => (
        <Sfx key={`i${c}`} name="impact" at={c} volume={0.75} />
      ))}
      <Sfx name="glitch" at={258} volume={0.55} />
      {WORD_CUES.map((c) => (
        <Sfx key={`s${c}`} name="stamp" at={c - 1} volume={0.7} />
      ))}
      <Sfx name="stamp" at={539} volume={0.9} />
      <Sfx name="sizzle" at={300} volume={0.25} />
    </AbsoluteFill>
  );
};
