import React from "react";
import { AbsoluteFill, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C, FONT } from "../constants/theme";
import { CUES, DIALOGS, wordCount, wordFrames } from "../constants/dialogs";
import { EASE, impact, jitter, ramp } from "../utils/anim";
import { SceneFX } from "../components/GlitchFX";
import { BRollOverlay, SmokeCanvas, StrobeFlare } from "../components/BRollOverlay";
import { KineticGlitchText } from "../components/KineticGlitchText";
import { Sfx } from "../components/Sfx";

const VAULT = { cx: 700, cy: 460, r: 320 };
const TEXT_START = 40;
const TEXT_PER = 6;
const WORD_CUES = wordFrames(wordCount(DIALOGS.s1.overlay), TEXT_START, TEXT_PER);
const ALL_CUES = [...CUES.s1, ...WORD_CUES];

// ------------------------------------------------------------------ volumetric red emergency strobes
const Beam: React.FC<{ x: number; y: number; from: number; dir: 1 | -1 }> = ({ x, y, from, dir }) => {
  const frame = useCurrentFrame();
  const ang = ramp(frame, 0, 480, from, from + dir * 720, EASE.lin);
  const pulse = ramp(frame % 45, 0, 22, 1, 0.3, EASE.out);
  return (
    <>
      <div
        style={{
          position: "absolute",
          left: x - 1300,
          top: y - 1300,
          width: 2600,
          height: 2600,
          background: `conic-gradient(from ${ang}deg at 50% 50%, rgba(255,24,48,0.62) 0deg, rgba(255,24,48,0.14) 14deg, transparent 32deg, transparent 360deg)`,
          filter: "blur(22px)",
          mixBlendMode: "screen",
          opacity: pulse,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: x - 26,
          top: y - 26,
          width: 52,
          height: 52,
          borderRadius: "50%",
          background: `radial-gradient(circle, #fff 0%, ${C.red} 40%, ${C.redDeep} 100%)`,
          boxShadow: `0 0 ${30 + 60 * pulse}px ${C.red}, 0 0 ${80 * pulse}px ${C.red}`,
        }}
      />
    </>
  );
};

// ------------------------------------------------------------------ heavy steel vault door
const VaultDoor: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { cx, cy, r } = VAULT;
  const enter = Math.min(1, spring({ frame, fps, config: { damping: 18, stiffness: 60, mass: 1.4 } }));
  const yaw = ramp(frame, 0, 300, -38, -6, EASE.inOut) + ramp(frame, 300, 480, 0, 18, EASE.inOut);
  const wheel = spring({ frame: frame - 30, fps, config: { damping: 24, stiffness: 22, mass: 2.2 } }) * 900;
  const bolt = ramp(frame, 268, 300, 0, 1, EASE.out);
  const glint = ramp(frame, 0, 480, -60, 160, EASE.inOut);
  const led = impact(frame % 30, [0], 12);
  const D = r * 2;
  const outer = (r + 40) * 2;
  const ring = (inset: number): React.CSSProperties => ({
    position: "absolute",
    left: inset,
    top: inset,
    right: inset,
    bottom: inset,
    borderRadius: "50%",
    border: "6px solid rgba(0,0,0,0.55)",
    boxShadow: "0 0 0 2px rgba(255,255,255,0.14), inset 0 0 24px rgba(0,0,0,0.5)",
  });

  return (
    <div
      style={{
        position: "absolute",
        left: cx - r - 40,
        top: cy - r - 40,
        width: outer,
        height: outer,
        opacity: Math.min(1, enter * 1.6),
        transform: `perspective(1800px) rotateY(${yaw}deg) scale(${0.82 + 0.18 * enter})`,
      }}
    >
      {/* recessed frame */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: "50%",
          background: "radial-gradient(circle, #07090d 55%, #1a1f27 100%)",
          boxShadow: "0 0 0 10px #0c0f14, 0 0 0 20px #39414d, 0 50px 140px rgba(0,0,0,0.95)",
        }}
      />
      {/* door disc */}
      <div
        style={{
          position: "absolute",
          left: 40,
          top: 40,
          width: D,
          height: D,
          borderRadius: "50%",
          background:
            "radial-gradient(circle at 32% 26%, #f0f4f8 0%, #a7b2c0 18%, #566170 48%, #222831 82%, #10131a 100%)",
          boxShadow: "inset 0 0 90px rgba(0,0,0,0.85)",
        }}
      >
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "50%",
            background:
              "conic-gradient(from 20deg, rgba(255,255,255,0.16), rgba(255,255,255,0) 12%, rgba(255,255,255,0.12) 25%, rgba(0,0,0,0.25) 40%, rgba(255,255,255,0.14) 55%, rgba(0,0,0,0.2) 75%, rgba(255,255,255,0.16))",
            mixBlendMode: "overlay",
          }}
        />
        <div style={ring(r * 0.1)} />
        <div style={ring(r * 0.26)} />
        <div style={ring(r * 0.44)} />

        {/* locking bolts */}
        {Array.from({ length: 16 }).map((_, i) => (
          <div
            key={i}
            style={{
              position: "absolute",
              left: r - 19,
              top: r - 19,
              width: 38,
              height: 38,
              borderRadius: "50%",
              background: "radial-gradient(circle at 35% 30%, #e9eef4, #6a7686 55%, #1a1f27)",
              boxShadow: "0 4px 10px rgba(0,0,0,0.7)",
              transform: `rotate(${i * 22.5}deg) translateY(${-(r * 0.86 - bolt * 46)}px)`,
            }}
          />
        ))}

        {/* hub + hand-wheel */}
        <div
          style={{
            position: "absolute",
            left: r - r * 0.3,
            top: r - r * 0.3,
            width: r * 0.6,
            height: r * 0.6,
            borderRadius: "50%",
            background: "radial-gradient(circle at 35% 30%, #5b6676, #1b2027 70%)",
            boxShadow: "0 0 0 6px #0b0e13, inset 0 0 30px rgba(0,0,0,0.8)",
          }}
        />
        <div style={{ position: "absolute", left: r, top: r, width: 0, height: 0, transform: `rotate(${wheel}deg)` }}>
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                left: -9,
                top: -r * 0.52,
                width: 18,
                height: r * 0.52,
                transformOrigin: "50% 100%",
                transform: `rotate(${i * 60}deg)`,
                background: "linear-gradient(90deg, #4b5564, #dfe6ee 45%, #4b5564)",
                borderRadius: 9,
                boxShadow: "0 4px 10px rgba(0,0,0,0.6)",
              }}
            >
              <div
                style={{
                  position: "absolute",
                  left: -13,
                  top: -16,
                  width: 44,
                  height: 44,
                  borderRadius: "50%",
                  background: "radial-gradient(circle at 35% 30%, #f3f6fa, #6a7686 60%, #1a1f27)",
                }}
              />
            </div>
          ))}
          <div style={{ position: "absolute", left: -30, top: -30, width: 60, height: 60, borderRadius: "50%", background: "radial-gradient(circle at 35% 30%, #f3f6fa, #566170 60%, #111)" }} />
        </div>

        {/* moving specular glint */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            borderRadius: "50%",
            background: `linear-gradient(105deg, transparent ${glint - 14}%, rgba(255,255,255,0.24) ${glint}%, transparent ${glint + 14}%)`,
          }}
        />
        {/* status LED + plate */}
        <div style={{ position: "absolute", left: r - 12, top: r * 0.14, width: 24, height: 24, borderRadius: "50%", background: C.red, boxShadow: `0 0 ${20 + 40 * led}px ${C.red}` }} />
        <div style={{ position: "absolute", left: r - 110, top: r * 1.62, width: 220, height: 34, borderRadius: 4, background: "#10141a", border: "1px solid #566170", color: C.red, fontFamily: FONT.mono, fontWeight: 700, fontSize: 15, letterSpacing: "0.2em", display: "flex", alignItems: "center", justifyContent: "center" }}>
          SEALED · 7X
        </div>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------ laser tripwires
const Lasers: React.FC = () => {
  const frame = useCurrentFrame();
  const env = impact(frame, CUES.s1, 12);
  const sweep = ramp(frame, 0, 480, -34, 34, EASE.inOut);
  const lines = Array.from({ length: 7 }).map((_, i) => {
    const s = i % 2 ? -1 : 1;
    const yL = 130 + i * 118 + sweep * s;
    const yR = 90 + i * 124 - sweep * s;
    const hit = i === Math.floor(frame / 40) % 7 ? env : 0;
    const dot = ramp((frame + i * 37) % 160, 0, 160, 0, 1, EASE.lin);
    return { i, yL, yR, hit, dot };
  });
  return (
    <svg width={1920} height={1080} style={{ position: "absolute", left: 0, top: 0, filter: `drop-shadow(0 0 8px ${C.red})`, mixBlendMode: "screen" }}>
      {lines.map(({ i, yL, yR, hit, dot }) => (
        <g key={i}>
          <line x1={0} y1={yL} x2={1920} y2={yR} stroke={C.red} strokeWidth={2.4 + hit * 6} opacity={0.8} />
          {hit > 0.05 ? <line x1={0} y1={yL} x2={1920} y2={yR} stroke="#fff" strokeWidth={1.5 + hit * 3} opacity={hit} /> : null}
          <circle cx={dot * 1920} cy={yL + (yR - yL) * dot} r={5} fill="#fff" />
          <rect x={0} y={yL - 9} width={18} height={18} fill="#1b1015" stroke={C.red} />
          <rect x={1902} y={yR - 9} width={18} height={18} fill="#1b1015" stroke={C.red} />
        </g>
      ))}
    </svg>
  );
};

// ------------------------------------------------------------------ vintage glass bottle in display case
const BOTTLE_PATH =
  "M 86 10 L 114 10 L 114 30 C 114 38, 110 42, 110 48 L 110 120 C 110 150, 135 170, 150 215 C 158 235, 160 260, 158 300 C 156 340, 140 360, 142 400 C 144 440, 163 470, 160 520 C 158 560, 152 575, 146 585 L 54 585 C 48 575, 42 560, 40 520 C 37 470, 56 440, 58 400 C 60 360, 44 340, 42 300 C 40 260, 42 235, 50 215 C 65 170, 90 150, 90 120 L 90 48 C 90 42, 86 38, 86 30 Z";

const BottleDisplay: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1, spring({ frame: frame - 10, fps, config: { damping: 20, stiffness: 70, mass: 1.2 } }));
  const env = impact(frame, CUES.s1, 10);
  const jx = jitter("bj", frame) * 8 * env;
  const spot = ramp(frame, 20, 90, 0, 1, EASE.out);
  return (
    <div
      style={{
        position: "absolute",
        left: 1330,
        top: 150,
        width: 440,
        height: 700,
        opacity: enter,
        transform: `translate(${jx + (1 - enter) * 160}px, 0px)`,
      }}
    >
      {/* glass case */}
      <div
        style={{
          position: "absolute",
          left: 40,
          top: 30,
          width: 360,
          height: 640,
          background: `radial-gradient(ellipse at 50% 38%, rgba(255,110,60,${0.55 * spot}), rgba(30,10,12,0.92) 72%)`,
          border: "3px solid rgba(255,255,255,0.28)",
          boxShadow: `inset 0 0 90px rgba(0,0,0,0.85), 0 0 70px rgba(255,30,50,0.3)`,
          overflow: "hidden",
        }}
      >
        <div style={{ position: "absolute", left: 70, top: 0, width: 220, height: 380, background: "linear-gradient(180deg, rgba(255,240,220,0.5), transparent)", clipPath: "polygon(36% 0, 64% 0, 100% 100%, 0 100%)", opacity: spot }} />
        <svg viewBox="0 0 200 600" width={170} height={510} style={{ position: "absolute", left: 95, top: 70 }}>
          <defs>
            <linearGradient id="bottleFill" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stopColor="#050507" />
              <stop offset="0.5" stopColor="#14141a" />
              <stop offset="1" stopColor="#050507" />
            </linearGradient>
          </defs>
          <path d={BOTTLE_PATH} fill="url(#bottleFill)" stroke="rgba(255,255,255,0.45)" strokeWidth={2} />
          <path d="M 70 200 C 62 260, 66 330, 74 380" fill="none" stroke="rgba(255,255,255,0.35)" strokeWidth={3} strokeLinecap="round" />
        </svg>
        <SmokeCanvas width={360} height={640} count={64} color={[215, 215, 225]} spread={240} size={70} alpha={0.2} rate={1.1} rise={1} seed="bottle-smoke" style={{ left: 0, top: 0 }} />
        <div style={{ position: "absolute", inset: 0, background: "linear-gradient(115deg, rgba(255,255,255,0.14) 0%, rgba(255,255,255,0) 30%, rgba(255,255,255,0) 64%, rgba(255,255,255,0.08) 100%)" }} />
      </div>
      <div style={{ position: "absolute", left: 20, top: 8, width: 400, height: 22, background: "linear-gradient(180deg,#9aa5b3,#3b4350)", borderRadius: 4 }} />
      <div style={{ position: "absolute", left: 20, top: 672, width: 400, height: 22, background: "linear-gradient(180deg,#9aa5b3,#3b4350)", borderRadius: 4 }} />
      <div style={{ position: "absolute", left: 40, top: 700, width: 360, textAlign: "center", fontFamily: FONT.mono, fontWeight: 700, fontSize: 15, letterSpacing: "0.3em", color: C.red }}>
        SPECIMEN · RESTRICTED
      </div>
    </div>
  );
};

// ------------------------------------------------------------------ glitchy warning HUD card
const HUD_LINES = ["VAULT STATUS : SEALED", "ACCESS LEVEL : 2 PERSONS ONLY", "RECIPE       : ########"];

const WarningHud: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1, spring({ frame: frame - 6, fps, config: { damping: 14, stiffness: 120, mass: 0.8 } }));
  const g = impact(frame, ALL_CUES, 10);
  const jx = jitter("hx", frame) * 12 * g;
  const jy = jitter("hy", frame) * 6 * g;
  const prog = ramp(frame, 20, 420, 0, 100, EASE.inOut);
  const blink = ramp(frame % 30, 0, 14, 1, 0.25, EASE.out);
  return (
    <div
      style={{
        position: "absolute",
        left: 60,
        top: 60,
        width: 560,
        opacity: enter,
        transform: `translate(${jx - (1 - enter) * 120}px, ${jy}px)`,
        background: "rgba(22,4,9,0.82)",
        border: `2px solid ${C.red}`,
        boxShadow: `0 0 40px rgba(255,23,48,0.45), inset 0 0 40px rgba(255,23,48,0.12)`,
        textShadow: g > 0.2 ? `${4 * g}px 0 ${C.cyan}, ${-4 * g}px 0 ${C.red}` : undefined,
      }}
    >
      <div style={{ background: C.red, display: "flex", alignItems: "center", gap: 14, padding: "6px 16px" }}>
        <div style={{ width: 0, height: 0, borderLeft: "13px solid transparent", borderRight: "13px solid transparent", borderBottom: "22px solid #0a0b10", position: "relative" }} />
        <div style={{ fontFamily: FONT.latinHero, fontSize: 36, letterSpacing: "0.08em", color: "#0a0b10", lineHeight: 1.1 }}>CLASSIFIED // TOP SECRET</div>
      </div>
      <div style={{ padding: "14px 18px 16px" }}>
        {HUD_LINES.map((line, i) => {
          const n = Math.floor(ramp(frame, 24 + i * 22, 24 + i * 22 + 26, 0, line.length, EASE.out));
          return (
            <div key={i} style={{ fontFamily: FONT.mono, fontWeight: 500, fontSize: 21, color: C.white, lineHeight: 1.6, whiteSpace: "pre" }}>
              {line.slice(0, n)}
              {i === 2 && n >= line.length ? <span style={{ opacity: blink, color: C.red }}> ▌</span> : null}
            </div>
          );
        })}
        <div style={{ fontFamily: FONT.bengaliBody, fontWeight: 700, fontSize: 26, color: C.red, marginTop: 6 }}>অতি গোপন — প্রবেশ নিষেধ</div>
        <div style={{ marginTop: 10, height: 10, background: "rgba(255,255,255,0.1)" }}>
          <div style={{ height: "100%", width: `${prog}%`, background: C.red, boxShadow: `0 0 14px ${C.red}` }} />
        </div>
        <div style={{ fontFamily: FONT.mono, fontSize: 14, color: C.steel, letterSpacing: "0.2em", marginTop: 6 }}>DECRYPTING {Math.round(prog)}%</div>
      </div>
    </div>
  );
};

export const Scene1: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const chapter = Math.min(1, spring({ frame: frame - 14, fps, config: { damping: 16, stiffness: 120, mass: 0.7 } }));
  const strobe = ramp(frame % 45, 0, 3, 0.35, 0, EASE.out) * (frame % 45 < 3 ? 1 : 0);

  return (
    <AbsoluteFill style={{ backgroundColor: C.bg }}>
      <SceneFX id="ca-s1" cues={ALL_CUES} flashColor={C.red}>
        <AbsoluteFill style={{ background: "radial-gradient(ellipse at 40% 48%, #1c0b0f 0%, #07070a 62%, #030305 100%)" }} />
        <Beam x={90} y={70} from={20} dir={1} />
        <Beam x={1830} y={70} from={200} dir={-1} />
        <VaultDoor />
        <Lasers />
        <BottleDisplay />
        <WarningHud />

        {/* chapter tag */}
        <div
          style={{
            position: "absolute",
            right: 70,
            top: 62,
            textAlign: "right",
            opacity: chapter,
            transform: `translateX(${(1 - chapter) * 120}px)`,
          }}
        >
          <div style={{ fontFamily: FONT.mono, fontWeight: 700, fontSize: 18, letterSpacing: "0.3em", color: C.red }}>CHAPTER 01</div>
          <div style={{ fontFamily: FONT.bengaliHero, fontWeight: 900, fontSize: 44, color: C.white, lineHeight: 1.4 }}>{DIALOGS.s1.chapter}</div>
        </div>

        {/* bottom scrim + kinetic text */}
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 360, background: "linear-gradient(180deg, transparent, rgba(0,0,0,0.82))" }} />
        <div style={{ position: "absolute", left: 0, right: 0, bottom: 48, display: "flex", justifyContent: "center" }}>
          <KineticGlitchText
            text={DIALOGS.s1.overlay}
            startFrame={TEXT_START}
            perWord={TEXT_PER}
            fontSize={104}
            accent={C.red}
            highlight={[1, 2]}
            glitchFrames={CUES.s1}
          />
        </div>

        <AbsoluteFill style={{ background: C.red, opacity: strobe, mixBlendMode: "screen" }} />
        <StrobeFlare cues={[0, 270]} x={1830} y={70} color={C.red} />
        <StrobeFlare cues={[120, 330]} x={90} y={70} color={C.red} />
      </SceneFX>
      <BRollOverlay tint={C.red} />

      <Sfx name="riser" at={0} volume={0.45} />
      {CUES.s1.map((c) => (
        <Sfx key={`i${c}`} name="impact" at={c} volume={0.75} />
      ))}
      {[0, 144, 288, 432].map((c) => (
        <Sfx key={`a${c}`} name="alarm" at={c} volume={0.3} />
      ))}
      {[120, 330].map((c) => (
        <Sfx key={`l${c}`} name="laser" at={c} volume={0.5} />
      ))}
      {[TEXT_START - 1, 270].map((c) => (
        <Sfx key={`g${c}`} name="glitch" at={c} volume={0.5} />
      ))}
      <Sfx name="whoosh" at={4} volume={0.4} />
    </AbsoluteFill>
  );
};
