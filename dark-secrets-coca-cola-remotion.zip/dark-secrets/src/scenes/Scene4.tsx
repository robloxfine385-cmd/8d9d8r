import React from "react";
import { AbsoluteFill, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C, FONT } from "../constants/theme";
import { CUES, DIALOGS, wordCount, wordFrames } from "../constants/dialogs";
import { EASE, impact, jitter, ramp } from "../utils/anim";
import { SceneFX, WhipZoom } from "../components/GlitchFX";
import { Burst, BurstCanvas, BRollOverlay, RainCanvas, Shockwave, SmokeCanvas, StrobeFlare } from "../components/BRollOverlay";
import { KineticGlitchText } from "../components/KineticGlitchText";
import { Sfx } from "../components/Sfx";

const BOOM = 360; // badge explosion
const WHIP = [120, 240, 480];
const BELL = [400, 480, 540];
const TEXT_START = 20;
const TEXT_PER = 5;
const ALL_CUES = [...CUES.s4, ...wordFrames(wordCount(DIALOGS.s4.overlay), TEXT_START, TEXT_PER)];
const CENTER = { x: 960, y: 560 };

// ------------------------------------------------------------------ studio backdrop
const Studio: React.FC = () => {
  const frame = useCurrentFrame();
  const env = impact(frame, ALL_CUES, 18);
  const cone = (x: number, w: number, color: string, k: number) => (
    <div
      key={k}
      style={{
        position: "absolute",
        left: x - w / 2,
        top: -60,
        width: w,
        height: 900,
        background: `linear-gradient(180deg, ${color}, transparent 85%)`,
        clipPath: "polygon(38% 0, 62% 0, 100% 100%, 0 100%)",
        filter: "blur(18px)",
        mixBlendMode: "screen",
        opacity: 0.45 + 0.4 * env,
      }}
    />
  );
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at 50% 40%, #1a0508 0%, #07070b 65%, #020204 100%)" }} />
      {cone(380, 560, "rgba(255,255,255,0.45)", 0)}
      {cone(960, 700, "rgba(255,40,60,0.55)", 1)}
      {cone(1540, 560, "rgba(255,255,255,0.45)", 2)}
      <div style={{ position: "absolute", left: 0, right: 0, top: 790, height: 290, background: "linear-gradient(180deg, rgba(255,23,48,0.2), rgba(0,0,0,0.9))" }} />
      <div style={{ position: "absolute", left: 0, right: 0, top: 788, height: 3, background: C.red, boxShadow: `0 0 30px ${C.red}`, opacity: 0.7 + 0.3 * env }} />
      <SmokeCanvas width={1920} height={520} count={60} color={[255, 40, 60]} spread={1900} size={170} alpha={0.12} rate={0.7} rise={0.7} baseX={0.5} seed="haze" style={{ left: 0, top: 560 }} />
      <RainCanvas width={1920} height={1080} count={150} speed={1} len={5} drift={0.2} seed="fizz-sparks" />
    </AbsoluteFill>
  );
};

// ------------------------------------------------------------------ charging core -> glossy SUBSCRIBE badge
const Core: React.FC = () => {
  const frame = useCurrentFrame();
  if (frame >= BOOM) return null;
  const size = ramp(frame, 0, BOOM - 5, 40, 240, EASE.in);
  const jx = jitter("cx", frame) * ramp(frame, 0, BOOM, 1, 14, EASE.in);
  const jy = jitter("cy", frame) * ramp(frame, 0, BOOM, 1, 14, EASE.in);
  const pulse = ramp(frame % 30, 0, 15, 1, 0.5, EASE.out);
  return (
    <div
      style={{
        position: "absolute",
        left: CENTER.x - size / 2 + jx,
        top: CENTER.y - size / 2 + jy,
        width: size,
        height: size,
        borderRadius: "50%",
        background: `radial-gradient(circle, #fff 0%, ${C.red} 38%, ${C.redDeep} 72%, transparent 100%)`,
        boxShadow: `0 0 ${60 * pulse + 40}px ${C.red}, 0 0 ${140 * pulse}px ${C.red}`,
      }}
    />
  );
};

const Badge: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame < BOOM) return null;
  const p = spring({ frame: frame - BOOM, fps, config: { damping: 8, stiffness: 150, mass: 0.8 } });
  const env = impact(frame, [400, 480, 540], 22);
  const vib = 1.2 + env * 7;
  const jx = jitter("bx", frame) * vib;
  const jy = jitter("by", frame) * vib;
  const yaw = ramp(frame, BOOM, 600, -16, 8, EASE.inOut);
  const tilt = ramp(frame, BOOM, BOOM + 30, 24, 4, EASE.out);
  const sheen = ramp((frame - BOOM) % 90, 0, 60, -30, 130, EASE.inOut);
  return (
    <div
      style={{
        position: "absolute",
        left: CENTER.x - 320,
        top: CENTER.y - 90,
        width: 640,
        height: 180,
        transform: `perspective(1400px) rotateX(${tilt}deg) rotateY(${yaw}deg) translate(${jx}px, ${jy}px) scale(${Math.max(0.01, 0.1 + 0.9 * p)})`,
      }}
    >
      <div
        style={{
          position: "absolute",
          inset: 0,
          borderRadius: 90,
          background: "linear-gradient(180deg, #ff6b7d 0%, #ff1730 46%, #b80d26 100%)",
          boxShadow: "0 14px 0 #6e0814, 0 40px 80px rgba(255,23,48,0.55), 0 0 90px rgba(255,23,48,0.85), inset 0 4px 0 rgba(255,255,255,0.7), inset 0 -14px 22px rgba(0,0,0,0.3)",
          border: "3px solid rgba(255,205,210,0.85)",
          overflow: "hidden",
        }}
      >
        <div style={{ position: "absolute", left: 18, right: 18, top: 8, height: "46%", borderRadius: 70, background: "linear-gradient(180deg, rgba(255,255,255,0.6), rgba(255,255,255,0))" }} />
        <div style={{ position: "absolute", top: 0, bottom: 0, left: `${sheen}%`, width: "16%", transform: "skewX(-20deg)", background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.5), transparent)" }} />
      </div>
      <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", gap: 26 }}>
        <div style={{ width: 0, height: 0, borderTop: "28px solid transparent", borderBottom: "28px solid transparent", borderLeft: `46px solid ${C.white}`, filter: "drop-shadow(0 3px 6px rgba(0,0,0,0.45))" }} />
        <div style={{ fontFamily: FONT.latinHero, fontSize: 132, lineHeight: 1, letterSpacing: "0.06em", color: C.white, textShadow: "0 4px 10px rgba(0,0,0,0.5)" }}>SUBSCRIBE</div>
      </div>
    </div>
  );
};

// ------------------------------------------------------------------ vibrating notification bell
const Bell: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const enter = Math.min(1.1, spring({ frame: frame - 380, fps, config: { damping: 9, stiffness: 160, mass: 0.7 } }));
  const env = impact(frame, BELL, 40);
  const rot = Math.sin(frame * 1.15) * 34 * env;
  const dot = frame >= 400 ? Math.max(0, spring({ frame: frame - 400, fps, config: { damping: 8, stiffness: 240, mass: 0.6 } })) : 0;
  if (frame < 380) return null;
  const arc = (side: 1 | -1, k: number) => {
    const a = impact(frame, BELL, 30);
    const s = 1 + (1 - a) * 0.6 * k;
    return (
      <path
        key={`${side}${k}`}
        d={side === 1 ? "M 22 4 Q 26 12 22 20" : "M 2 4 Q -2 12 2 20"}
        fill="none"
        stroke={C.amber}
        strokeWidth={1.2}
        strokeLinecap="round"
        opacity={a * (1 - k * 0.3)}
        transform={`translate(12 12) scale(${s}) translate(-12 -12)`}
      />
    );
  };
  return (
    <div style={{ position: "absolute", left: 1400, top: 450, width: 200, height: 200, transform: `scale(${Math.max(0, enter)})` }}>
      <div style={{ width: 200, height: 200, transform: `rotate(${rot}deg)`, transformOrigin: "50% 10%" }}>
        <svg viewBox="0 0 24 24" width={200} height={200} style={{ overflow: "visible", filter: `drop-shadow(0 0 ${16 + 30 * env}px ${C.amber})` }}>
          <defs>
            <linearGradient id="bellGrad4" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#fff" />
              <stop offset="0.35" stopColor={C.amber} />
              <stop offset="1" stopColor="#6b4a10" />
            </linearGradient>
          </defs>
          <path d="M12 2c-.8 0-1.5.7-1.5 1.5v.6C7.9 4.8 6 7.2 6 10v4l-2 2.5V18h16v-1.5L18 14v-4c0-2.8-1.9-5.2-4.5-5.9v-.6C13.5 2.7 12.8 2 12 2z" fill="url(#bellGrad4)" />
          <path d="M10 19.2a2 2 0 0 0 4 0z" fill={C.amber} />
          {[0, 1].map((k) => arc(1, k))}
          {[0, 1].map((k) => arc(-1, k))}
        </svg>
      </div>
      <div style={{ position: "absolute", right: 14, top: 8, width: 54, height: 54, borderRadius: "50%", background: C.red, border: `4px solid ${C.white}`, color: C.white, fontFamily: FONT.latinHero, fontSize: 38, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${dot})`, boxShadow: `0 0 22px ${C.red}` }}>1</div>
    </div>
  );
};

const Chip: React.FC<{ label: string; x: number; at: number; accent: string }> = ({ label, x, at, accent }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame < at) return null;
  const p = spring({ frame: frame - at, fps, config: { damping: 9, stiffness: 220, mass: 0.6 } });
  return (
    <div
      style={{
        position: "absolute",
        left: x,
        top: 830,
        padding: "8px 40px",
        fontFamily: FONT.latinHero,
        fontSize: 52,
        letterSpacing: "0.12em",
        color: C.white,
        background: "rgba(255,255,255,0.08)",
        border: `2px solid ${accent}`,
        boxShadow: `0 0 28px ${accent}`,
        backdropFilter: "blur(10px)",
        transform: `scale(${Math.max(0, p)})`,
      }}
    >
      {label}
    </div>
  );
};

export const Scene4: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const chapter = Math.min(1, spring({ frame: frame - 8, fps, config: { damping: 16, stiffness: 120, mass: 0.7 } }));
  const whip = impact(frame, WHIP, 16);
  const fade = ramp(frame, 572, 600, 0, 1, EASE.in);
  const fin = impact(frame, [540], 10) * 0.5;

  const debris: Burst[] = [
    { at: BOOM, x: CENTER.x, y: CENTER.y, count: 110, speed: 22, spread: Math.PI, gravity: 0.25, life: 60, color: [255, 40, 60], size: 5, seed: "deb1" },
    { at: BOOM, x: CENTER.x, y: CENTER.y, count: 70, speed: 16, spread: Math.PI, gravity: 0.2, life: 50, color: [255, 245, 235], size: 3.5, seed: "deb2" },
    { at: BOOM + 4, x: CENTER.x, y: CENTER.y, count: 60, speed: 12, spread: Math.PI, gravity: 0.2, life: 46, color: [255, 176, 32], size: 3, seed: "deb3" },
    { at: 540, x: CENTER.x, y: CENTER.y, count: 70, speed: 17, spread: Math.PI, gravity: 0.2, life: 44, color: [255, 40, 60], size: 3.5, seed: "deb4" },
  ];

  return (
    <AbsoluteFill style={{ backgroundColor: C.bg }}>
      <SceneFX id="ca-s4" cues={ALL_CUES} base={0.02} flashColor="#ff4a5c">
        <WhipZoom events={WHIP}>
          <Studio />
          <Core />
          <BurstCanvas width={1920} height={1080} bursts={debris} style={{ left: 0, top: 0 }} />
          <Shockwave at={BOOM} x={CENTER.x} y={CENTER.y} size={900} count={4} stagger={6} life={60} color={C.red} thickness={6} />
          <Shockwave at={BOOM + 3} x={CENTER.x} y={CENTER.y} size={700} count={2} stagger={8} life={50} color={C.white} thickness={3} />
          <Shockwave at={540} x={CENTER.x} y={CENTER.y} size={800} count={3} stagger={7} life={52} color={C.red} thickness={5} />
          <Badge />
          <Bell />
          <Chip label="LIKE" x={470} at={420} accent={C.cyan} />
          <Chip label="SHARE" x={780} at={436} accent={C.amber} />
          <Chip label="SUBSCRIBE" x={1130} at={452} accent={C.red} />

          {/* top call-to-action */}
          <div style={{ position: "absolute", left: 0, right: 0, top: 120, display: "flex", justifyContent: "center" }}>
            <KineticGlitchText
              text={DIALOGS.s4.overlay}
              startFrame={TEXT_START}
              perWord={TEXT_PER}
              fontSize={92}
              accent={C.red}
              highlight={[0, 1, 5]}
              emphasis={[{ frame: BOOM, indices: [3, 4, 5] }]}
              glitchFrames={CUES.s4}
            />
          </div>

          <div style={{ position: "absolute", right: 70, top: 56, textAlign: "right", opacity: chapter, transform: `translateX(${(1 - chapter) * 120}px)` }}>
            <div style={{ fontFamily: FONT.mono, fontWeight: 700, fontSize: 16, letterSpacing: "0.3em", color: C.red }}>CHAPTER 04</div>
            <div style={{ fontFamily: FONT.bengaliHero, fontWeight: 900, fontSize: 38, color: C.white, lineHeight: 1.3 }}>{DIALOGS.s4.chapter}</div>
          </div>
        </WhipZoom>

        {/* whip-zoom radial speed lines */}
        <AbsoluteFill
          style={{
            background: "repeating-conic-gradient(from 0deg at 50% 50%, rgba(255,255,255,0) 0deg 4deg, rgba(255,255,255,0.22) 4deg 5deg)",
            WebkitMaskImage: "radial-gradient(circle, transparent 30%, #000 85%)",
            maskImage: "radial-gradient(circle, transparent 30%, #000 85%)",
            opacity: whip,
            mixBlendMode: "screen",
            pointerEvents: "none",
          }}
        />
        <StrobeFlare cues={[BOOM, 540]} x={CENTER.x} y={CENTER.y} color={C.red} />
        <StrobeFlare cues={[240, 480]} x={380} y={80} color="#ffffff" />
        <AbsoluteFill style={{ background: C.red, opacity: fin, mixBlendMode: "screen" }} />
      </SceneFX>
      <BRollOverlay tint={C.red} />
      <AbsoluteFill style={{ background: "#000", opacity: fade, pointerEvents: "none" }} />

      <Sfx name="riser" at={250} volume={0.55} />
      {CUES.s4.map((c) => (
        <Sfx key={`i${c}`} name="impact" at={c} volume={c === BOOM ? 0.95 : 0.7} />
      ))}
      <Sfx name="glitch" at={BOOM - 2} volume={0.6} />
      <Sfx name="shock" at={BOOM} volume={0.8} />
      {WHIP.map((c) => (
        <Sfx key={`w${c}`} name="whoosh" at={c - 2} volume={0.55} />
      ))}
      {BELL.map((c) => (
        <Sfx key={`d${c}`} name="ding" at={c} volume={0.4} />
      ))}
      <Sfx name="shock" at={540} volume={0.6} />
    </AbsoluteFill>
  );
};
