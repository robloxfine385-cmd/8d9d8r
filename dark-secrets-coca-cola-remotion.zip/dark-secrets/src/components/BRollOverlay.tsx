import React, { useLayoutEffect, useMemo, useRef } from "react";
import { AbsoluteFill, interpolate, random, useCurrentFrame } from "remotion";
import { C } from "../constants/theme";
import { EASE, impact, ramp } from "../utils/anim";

export type RGB = readonly [number, number, number];
const rgba = (c: RGB, a: number) => `rgba(${c[0]}, ${c[1]}, ${c[2]}, ${Math.max(0, Math.min(1, a))})`;

const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

/** Redraws synchronously after every React commit => fully deterministic per frame. */
const useCanvas = (w: number, h: number, draw: (ctx: CanvasRenderingContext2D) => void) => {
  const ref = useRef<HTMLCanvasElement>(null);
  useLayoutEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    ctx.globalCompositeOperation = "source-over";
    ctx.clearRect(0, 0, w, h);
    draw(ctx);
  });
  return ref;
};

// ------------------------------------------------------------------ fizzing fluid / acid bubbles
export const FizzCanvas: React.FC<{
  width: number;
  height: number;
  count?: number;
  color?: RGB;
  speed?: number;
  seed?: string;
  pop?: boolean;
  intensity?: number;
  style?: React.CSSProperties;
}> = ({ width, height, count = 120, color = [255, 200, 140], speed = 1, seed = "fz", pop = false, intensity = 1, style }) => {
  const frame = useCurrentFrame();
  const parts = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        x: random(`${seed}x${i}`),
        r: 1.5 + random(`${seed}r${i}`) * 6.5,
        s: 0.7 + random(`${seed}s${i}`) * 1.6,
        o: random(`${seed}o${i}`) * 2000,
        w: random(`${seed}w${i}`) * 6.28,
        a: 0.35 + random(`${seed}a${i}`) * 0.5,
      })),
    [count, seed],
  );
  const ref = useCanvas(width, height, (ctx) => {
    const travel = height + 60;
    const show = Math.floor(count * Math.min(1, Math.max(0, intensity)));
    for (let i = 0; i < show; i++) {
      const p = parts[i];
      const t = (frame * p.s * 1.3 * speed + p.o) % travel;
      const y = height + 20 - t;
      const x = p.x * width + Math.sin(frame * 0.06 + p.w) * (4 + p.r);
      if (y > -4) {
        const g = ctx.createRadialGradient(x - p.r * 0.35, y - p.r * 0.35, 0, x, y, p.r);
        g.addColorStop(0, `rgba(255,255,255,${0.85 * p.a})`);
        g.addColorStop(0.55, rgba(color, 0.28 * p.a));
        g.addColorStop(1, rgba(color, 0));
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.arc(x, y, p.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = rgba(color, 0.35 * p.a);
        ctx.lineWidth = 1;
        ctx.stroke();
      } else if (pop && y > -40) {
        const k = interpolate(-y, [4, 40], [0, 1], clamp);
        ctx.strokeStyle = rgba(color, 0.7 * (1 - k) * p.a);
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.ellipse(x, 0, p.r + k * 14, (p.r + k * 14) * 0.3, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
    }
  });
  return <canvas ref={ref} width={width} height={height} style={{ position: "absolute", ...style }} />;
};

// ------------------------------------------------------------------ smoke / fumes
export const SmokeCanvas: React.FC<{
  width: number;
  height: number;
  count?: number;
  color?: RGB;
  rate?: number;
  rise?: number;
  spread?: number;
  size?: number;
  alpha?: number;
  baseX?: number;
  seed?: string;
  style?: React.CSSProperties;
}> = ({ width, height, count = 70, color = [210, 210, 220], rate = 1, rise = 0.9, spread = 160, size = 60, alpha = 0.22, baseX = 0.5, seed = "sm", style }) => {
  const frame = useCurrentFrame();
  const parts = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        x: random(`${seed}x${i}`),
        l: 140 + random(`${seed}l${i}`) * 160,
        o: random(`${seed}o${i}`) * 1000,
        w: random(`${seed}w${i}`) * 6.28,
        s: 0.6 + random(`${seed}s${i}`) * 0.8,
      })),
    [count, seed],
  );
  const ref = useCanvas(width, height, (ctx) => {
    for (const p of parts) {
      const age = (frame * rate + p.o) % p.l;
      const t = age / p.l;
      const x = width * baseX + (p.x - 0.5) * spread + Math.sin(t * 5 + p.w) * 40 * t;
      const y = height - t * rise * height;
      const rad = size * p.s * (0.35 + t * 1.5);
      const a = alpha * interpolate(t, [0, 0.18, 1], [0, 1, 0], clamp);
      const g = ctx.createRadialGradient(x, y, 0, x, y, rad);
      g.addColorStop(0, rgba(color, a));
      g.addColorStop(1, rgba(color, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(x, y, rad, 0, Math.PI * 2);
      ctx.fill();
    }
  });
  return <canvas ref={ref} width={width} height={height} style={{ position: "absolute", ...style }} />;
};

// ------------------------------------------------------------------ bursts (splashes / debris)
export type Burst = {
  at: number;
  x: number;
  y: number;
  count: number;
  speed: number;
  spread: number;
  gravity: number;
  life: number;
  color: RGB;
  size: number;
  seed: string;
  angle?: number;
};

export const BurstCanvas: React.FC<{ width: number; height: number; bursts: Burst[]; style?: React.CSSProperties }> = ({
  width,
  height,
  bursts,
  style,
}) => {
  const frame = useCurrentFrame();
  const ref = useCanvas(width, height, (ctx) => {
    ctx.globalCompositeOperation = "lighter";
    ctx.lineCap = "round";
    for (const b of bursts) {
      const age = frame - b.at;
      if (age < 0 || age > b.life) continue;
      const life01 = age / b.life;
      const prev = Math.max(0, age - 2.5);
      for (let k = 0; k < b.count; k++) {
        const a = (b.angle ?? -Math.PI / 2) + (random(`${b.seed}a${k}`) - 0.5) * 2 * b.spread;
        const sp = b.speed * (0.35 + random(`${b.seed}s${k}`) * 0.95);
        const vx = Math.cos(a) * sp;
        const vy = Math.sin(a) * sp;
        const x1 = b.x + vx * age;
        const y1 = b.y + vy * age + 0.5 * b.gravity * age * age;
        const x0 = b.x + vx * prev;
        const y0 = b.y + vy * prev + 0.5 * b.gravity * prev * prev;
        ctx.strokeStyle = rgba(b.color, 1 - life01);
        ctx.lineWidth = Math.max(0.6, b.size * (1 - life01 * 0.6) * (0.6 + random(`${b.seed}w${k}`) * 0.8));
        ctx.beginPath();
        ctx.moveTo(x0, y0);
        ctx.lineTo(x1, y1);
        ctx.stroke();
      }
    }
  });
  return <canvas ref={ref} width={width} height={height} style={{ position: "absolute", ...style }} />;
};

// ------------------------------------------------------------------ falling carbonation sparks
export const RainCanvas: React.FC<{
  width: number;
  height: number;
  count?: number;
  colors?: RGB[];
  speed?: number;
  len?: number;
  drift?: number;
  seed?: string;
  style?: React.CSSProperties;
}> = ({ width, height, count = 120, colors = [[255, 240, 220], [255, 176, 32], [255, 23, 48]], speed = 1, len = 5, drift = 0.25, seed = "rn", style }) => {
  const frame = useCurrentFrame();
  const parts = useMemo(
    () =>
      Array.from({ length: count }, (_, i) => ({
        x: random(`${seed}x${i}`),
        s: random(`${seed}s${i}`),
        o: random(`${seed}o${i}`),
        c: Math.floor(random(`${seed}c${i}`) * 3),
      })),
    [count, seed],
  );
  const ref = useCanvas(width, height, (ctx) => {
    ctx.globalCompositeOperation = "lighter";
    ctx.lineCap = "round";
    const span = height + 300;
    for (const p of parts) {
      const sp = (5 + p.s * 10) * speed;
      const y = ((p.o * span + frame * sp) % span) - 150;
      const x = p.x * width + frame * drift * (0.4 + p.s);
      const xx = ((x % width) + width) % width;
      const col = colors[p.c % colors.length];
      const tail = len * sp;
      const g = ctx.createLinearGradient(xx, y, xx - drift * tail, y - tail);
      g.addColorStop(0, rgba(col, 0.95));
      g.addColorStop(1, rgba(col, 0));
      ctx.strokeStyle = g;
      ctx.lineWidth = 1.5 + p.s * 2;
      ctx.beginPath();
      ctx.moveTo(xx, y);
      ctx.lineTo(xx - drift * tail, y - tail);
      ctx.stroke();
      ctx.fillStyle = rgba(col, 0.9);
      ctx.beginPath();
      ctx.arc(xx, y, 1.8 + p.s * 2, 0, Math.PI * 2);
      ctx.fill();
    }
  });
  return <canvas ref={ref} width={width} height={height} style={{ position: "absolute", ...style }} />;
};

// ------------------------------------------------------------------ DOM shockwave rings
export const Shockwave: React.FC<{
  at: number;
  x: number;
  y: number;
  size?: number;
  count?: number;
  stagger?: number;
  life?: number;
  thickness?: number;
  color?: string;
}> = ({ at, x, y, size = 500, count = 3, stagger = 7, life = 56, thickness = 4, color = C.red }) => {
  const frame = useCurrentFrame();
  return (
    <>
      {Array.from({ length: count }).map((_, i) => {
        const age = frame - at - i * stagger;
        if (age < 0 || age > life) return null;
        const scale = ramp(age, 0, life, 0.06, 1, EASE.out);
        const o = ramp(age, 0, life, 1, 0, EASE.in);
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x - size / 2,
              top: y - size / 2,
              width: size,
              height: size,
              borderRadius: "50%",
              border: `${thickness}px solid ${color}`,
              transform: `scale(${scale})`,
              opacity: o,
              boxShadow: `0 0 28px ${color}, inset 0 0 28px ${color}`,
              pointerEvents: "none",
            }}
          />
        );
      })}
    </>
  );
};

// ------------------------------------------------------------------ strobe lens flare
export const StrobeFlare: React.FC<{
  cues: readonly number[];
  x: number;
  y: number;
  color?: string;
  base?: number;
}> = ({ cues, x, y, color = C.red, base = 0 }) => {
  const frame = useCurrentFrame();
  const env = Math.min(1, impact(frame, cues, 26) + base);
  if (env < 0.02) return null;
  const cx = 960;
  const cy = 540;
  const ghosts = [0.4, 0.85, 1.3, 1.8];
  return (
    <AbsoluteFill style={{ mixBlendMode: "screen", pointerEvents: "none", opacity: env }}>
      <div
        style={{
          position: "absolute",
          left: x - 300,
          top: y - 300,
          width: 600,
          height: 600,
          borderRadius: "50%",
          background: `radial-gradient(circle, rgba(255,255,255,0.95) 0%, ${color} 16%, transparent 62%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          left: x - 1100,
          top: y - 4,
          width: 2200,
          height: 8,
          background: `linear-gradient(90deg, transparent, ${color} 50%, transparent)`,
          filter: "blur(2px)",
        }}
      />
      {ghosts.map((k, i) => {
        const gx = x + (cx - x) * k;
        const gy = y + (cy - y) * k;
        const s = 70 + i * 55;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: gx - s / 2,
              top: gy - s / 2,
              width: s,
              height: s,
              borderRadius: "50%",
              border: `2px solid ${i % 2 ? C.cyan : color}`,
              opacity: 0.45,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

// ------------------------------------------------------------------ film grade overlay (vignette / scanlines / tint)
export const BRollOverlay: React.FC<{ tint?: string; strength?: number }> = ({ tint = C.red, strength = 1 }) => {
  const frame = useCurrentFrame();
  const flick = random(`flick-${frame}`);
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <AbsoluteFill style={{ backgroundColor: tint, mixBlendMode: "soft-light", opacity: 0.16 * strength }} />
      <AbsoluteFill
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, rgba(255,255,255,0.035) 0px, rgba(255,255,255,0.035) 1px, transparent 1px, transparent 3px)",
          backgroundPosition: `0px ${frame % 3}px`,
          opacity: 0.6 + 0.3 * flick,
          mixBlendMode: "overlay",
        }}
      />
      <AbsoluteFill style={{ background: "radial-gradient(ellipse at center, transparent 50%, rgba(0,0,0,0.62) 100%)" }} />
    </AbsoluteFill>
  );
};
