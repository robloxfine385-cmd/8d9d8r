import React from "react";
import { AbsoluteFill, random, useCurrentFrame } from "remotion";
import { C } from "../constants/theme";
import { impact, ramp, EASE } from "../utils/anim";
import { useEnergy } from "../utils/energy";

/** Deterministic per-frame camera shake (translate + roll + punch-in). */
export const CameraShake: React.FC<{ amount: number; children?: React.ReactNode }> = ({ amount, children }) => {
  const frame = useCurrentFrame();
  const a = Math.min(1, Math.max(0, amount));
  const dx = (random(`csx-${frame}`) - 0.5) * 2 * a * 34;
  const dy = (random(`csy-${frame}`) - 0.5) * 2 * a * 24;
  const rot = (random(`csr-${frame}`) - 0.5) * 2 * a * 1.4;
  const sc = 1 + a * 0.045;
  return (
    <AbsoluteFill style={{ transform: `translate(${dx}px, ${dy}px) rotate(${rot}deg) scale(${sc})` }}>
      {children}
    </AbsoluteFill>
  );
};

/** Real RGB-channel split via SVG filter (R shifted left, B shifted right). */
export const ChromaticAberration: React.FC<{ id: string; amount: number; children?: React.ReactNode }> = ({
  id,
  amount,
  children,
}) => {
  if (amount < 0.03) return <AbsoluteFill>{children}</AbsoluteFill>;
  const dx = Math.min(1, amount) * 16;
  return (
    <AbsoluteFill style={{ filter: `url(#${id})` }}>
      <svg width={0} height={0} style={{ position: "absolute" }}>
        <defs>
          <filter id={id} x="-5%" y="-5%" width="110%" height="110%" colorInterpolationFilters="sRGB">
            <feColorMatrix in="SourceGraphic" type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" result="r" />
            <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" result="g" />
            <feColorMatrix in="SourceGraphic" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" result="b" />
            <feOffset in="r" dx={-dx} dy={0} result="ro" />
            <feOffset in="b" dx={dx} dy={0} result="bo" />
            <feBlend in="ro" in2="g" mode="screen" result="rg" />
            <feBlend in="rg" in2="bo" mode="screen" />
          </filter>
        </defs>
      </svg>
      {children}
    </AbsoluteFill>
  );
};

/** Horizontal tear bars + hot lines (screen-blended). */
export const GlitchBars: React.FC<{ amount: number }> = ({ amount }) => {
  const frame = useCurrentFrame();
  if (amount < 0.05) return null;
  const colors = [C.cyan, C.red, C.white, C.cyan];
  return (
    <AbsoluteFill style={{ pointerEvents: "none", mixBlendMode: "screen" }}>
      {Array.from({ length: 8 }).map((_, i) => {
        const y = random(`gby-${i}-${frame}`) * 1080;
        const h = 4 + random(`gbh-${i}-${frame}`) * 70 * amount;
        const x = (random(`gbx-${i}-${frame}`) - 0.5) * 120 * amount;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: "100%",
              height: h,
              background: colors[i % colors.length],
              opacity: 0.1 + 0.28 * amount * random(`gbo-${i}-${frame}`),
            }}
          />
        );
      })}
      {Array.from({ length: 3 }).map((_, i) => (
        <div
          key={`t${i}`}
          style={{
            position: "absolute",
            left: 0,
            top: random(`gbt-${i}-${frame}`) * 1080,
            width: "100%",
            height: 2,
            background: C.white,
            opacity: 0.55 * amount,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

export const StrobeFlash: React.FC<{ opacity: number; color?: string }> = ({ opacity, color = C.white }) =>
  opacity < 0.01 ? null : (
    <AbsoluteFill style={{ background: color, opacity, mixBlendMode: "screen", pointerEvents: "none" }} />
  );

/** Whip-zoom: punch-in scale + radial motion blur on each event frame. */
export const WhipZoom: React.FC<{ events: readonly number[]; children?: React.ReactNode }> = ({ events, children }) => {
  const frame = useCurrentFrame();
  const env = impact(frame, events, 16);
  return (
    <AbsoluteFill
      style={{
        transform: `scale(${1 + env * 0.38})`,
        filter: env > 0.06 ? `blur(${env * 9}px)` : undefined,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};

/**
 * Scene wrapper: camera shake + chromatic aberration + glitch bars + strobe,
 * driven by scripted bass-drop cues AND the narration's loudness onsets.
 */
export const SceneFX: React.FC<{
  id: string;
  cues: readonly number[];
  base?: number;
  flashColor?: string;
  children?: React.ReactNode;
}> = ({ id, cues, base = 0, flashColor = C.white, children }) => {
  const frame = useCurrentFrame();
  const { flux } = useEnergy();
  const env = impact(frame, cues, 22);
  const shake = Math.min(1, Math.max(env, flux * 0.8) + base);
  const ca = Math.min(1, env * 1.1 + flux * 0.6);
  const flash = impact(frame, cues, 6) * 0.3;
  return (
    <AbsoluteFill>
      <ChromaticAberration id={id} amount={ca}>
        <CameraShake amount={shake}>{children}</CameraShake>
      </ChromaticAberration>
      <GlitchBars amount={Math.max(env > 0.45 ? env : 0, flux > 0.55 ? flux : 0)} />
      <StrobeFlash opacity={flash} color={flashColor} />
    </AbsoluteFill>
  );
};

/** Hard-cut glitch burst placed on scene boundaries. */
export const CutGlitch: React.FC<{ at: number }> = ({ at }) => {
  const frame = useCurrentFrame();
  const age = frame - (at - 3);
  if (age < 0 || age > 16) return null;
  const up = ramp(age, 0, 3, 0, 1, EASE.out);
  const down = ramp(age, 3, 16, 0, 1, EASE.out);
  const v = up * (1 - down);
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      <GlitchBars amount={v} />
      <StrobeFlash opacity={0.5 * v} />
    </AbsoluteFill>
  );
};
