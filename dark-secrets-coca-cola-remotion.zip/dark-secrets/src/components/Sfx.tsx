import React from "react";
import { Audio, Sequence, staticFile } from "remotion";

// clip lengths in frames @60fps — each <Audio> stays mounted only while it plays
const LEN: Record<string, number> = {
  impact: 96,
  glitch: 24,
  alarm: 150,
  laser: 32,
  splash: 42,
  sizzle: 130,
  heartbeat: 56,
  stamp: 28,
  whoosh: 56,
  riser: 100,
  shock: 80,
  ding: 90,
  tick: 6,
};

/** Frame-based SFX (scene-local frame). Place 1–2 frames BEFORE the visual hit. */
export const Sfx: React.FC<{ name: string; at: number; volume?: number }> = ({ name, at, volume = 0.6 }) => (
  <Sequence from={Math.max(0, Math.round(at))} durationInFrames={(LEN[name] ?? 60) + 2} layout="none">
    <Audio src={staticFile(`sfx/${name}.wav`)} volume={volume} />
  </Sequence>
);
