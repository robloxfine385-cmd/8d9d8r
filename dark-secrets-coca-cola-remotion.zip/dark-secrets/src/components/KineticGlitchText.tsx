import React from "react";
import { random, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { C, FONT } from "../constants/theme";
import { EASE, impact, ramp } from "../utils/anim";

const BENGALI = /[\u0980-\u09FF]/;

type Emphasis = { frame: number; indices: number[] };

type WordProps = {
  word: string;
  index: number;
  popFrame: number;
  size: number;
  variant: "pop" | "stamp";
  accent: string;
  hi: boolean;
  glitch: number;
};

const Word: React.FC<WordProps> = ({ word, index, popFrame, size, variant, accent, hi, glitch }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const bn = BENGALI.test(word);
  const fs = bn ? size : size * 1.22;
  const base: React.CSSProperties = {
    fontFamily: bn ? FONT.bengaliHero : FONT.latinHero,
    fontWeight: bn ? 900 : 400,
    fontSize: fs,
    lineHeight: bn ? 1.4 : 1.05,
    letterSpacing: bn ? 0 : "0.03em", // Bengali: never track letters, conjuncts must stay joined
    whiteSpace: "nowrap",
  };
  const age = frame - popFrame;

  // reserve layout before the pop so nothing shifts when words land
  if (age < 0) {
    return <span style={{ ...base, display: "inline-block", visibility: "hidden" }}>{word}</span>;
  }

  const stamp = variant === "stamp";
  const p = spring({
    frame: age,
    fps,
    config: stamp ? { damping: 9, stiffness: 260, mass: 0.7 } : { damping: 8, stiffness: 220, mass: 0.6 },
  });
  const s0 = stamp ? 3.4 : 0.15;
  const scale = 1 + (1 - p) * (s0 - 1); // spring overshoot => scale-bounce
  const rot = stamp ? -2 + (1 - p) * -9 : (1 - p) * (index % 2 ? 6 : -6);
  const op = ramp(age, 0, 2, 0, 1, EASE.out);
  const g = Math.max(glitch, ramp(age, 0, 10, 1, 0, EASE.out) * 0.8);
  const dx = 1.5 + g * 14;
  const color = hi ? accent : C.white;

  if (word === "|") {
    return (
      <div
        style={{
          width: Math.max(8, size * 0.09),
          height: size * 1.1,
          borderRadius: 6,
          background: accent,
          boxShadow: `0 0 26px ${accent}, 0 0 60px ${accent}`,
          opacity: op,
          transform: `scaleY(${Math.max(0, p)})`,
        }}
      />
    );
  }

  const ghost = (k: number) => {
    const a = age - k * 2;
    if (a < 0) return null;
    return (
      <span
        key={k}
        style={{
          ...base,
          position: "absolute",
          left: 0,
          top: 0,
          color: accent,
          opacity: ramp(a, 0, 16, 0.5, 0, EASE.out),
          transform: `scale(${1 + ramp(a, 0, 16, 0, 0.5 + 0.3 * k, EASE.out)})`,
          filter: `blur(${k * 2}px)`,
        }}
      >
        {word}
      </span>
    );
  };

  const slice = (i: number) => {
    const a = random(`ks-${index}-${i}-${frame}`) * 70;
    const h = 8 + random(`kh-${index}-${i}-${frame}`) * 22;
    const x = (random(`kx-${index}-${i}-${frame}`) - 0.5) * 70 * g;
    return (
      <span
        key={i}
        style={{
          ...base,
          position: "absolute",
          left: 0,
          top: 0,
          color: C.white,
          clipPath: `inset(${a}% 0 ${Math.max(0, 100 - a - h)}% 0)`,
          transform: `translateX(${x}px)`,
        }}
      >
        {word}
      </span>
    );
  };

  return (
    <div
      style={{
        position: "relative",
        display: "inline-block",
        opacity: op,
        transform: `scale(${scale}) rotate(${rot}deg)`,
      }}
    >
      {/* neon shockwave ring */}
      <div
        style={{
          position: "absolute",
          left: "-15%",
          top: "-45%",
          width: "130%",
          height: "190%",
          borderRadius: "50%",
          border: `3px solid ${accent}`,
          boxShadow: `0 0 30px ${accent}, inset 0 0 30px ${accent}`,
          opacity: ramp(age, 0, 18, 0.9, 0, EASE.out),
          transform: `scale(${ramp(age, 0, 18, 0.35, 1.7, EASE.out)})`,
        }}
      />
      {/* shockwave trail */}
      {[1, 2, 3].map(ghost)}
      {/* chromatic aberration */}
      <span style={{ ...base, position: "absolute", left: 0, top: 0, color: "#ff0030", transform: `translateX(${-dx}px)`, mixBlendMode: "screen", opacity: 0.9 }}>
        {word}
      </span>
      <span style={{ ...base, position: "absolute", left: 0, top: 0, color: C.cyan, transform: `translateX(${dx}px)`, mixBlendMode: "screen", opacity: 0.9 }}>
        {word}
      </span>
      {/* main */}
      <span
        style={{
          ...base,
          position: "relative",
          display: "inline-block",
          color,
          textShadow: stamp
            ? `0 6px 0 rgba(0,0,0,0.9), 0 0 40px ${accent}`
            : `0 0 28px ${accent}99, 0 8px 28px rgba(0,0,0,0.85)`,
        }}
      >
        {word}
      </span>
      {/* slice tears */}
      {g > 0.25 ? [0, 1].map(slice) : null}
    </div>
  );
};

/**
 * Word-level kinetic typography (Bengali-safe: never splits inside a word).
 * Each word pops frame-accurately with spring scale-bounce, neon shockwave ring + trail,
 * RGB split and slice glitch on pop and on `glitchFrames`.
 */
export const KineticGlitchText: React.FC<{
  text: string;
  startFrame?: number;
  perWord?: number;
  fontSize: number;
  variant?: "pop" | "stamp";
  accent?: string;
  highlight?: number[];
  emphasis?: Emphasis[];
  glitchFrames?: readonly number[];
  maxWidth?: number;
  align?: "center" | "flex-start";
  rowGap?: number;
  exitAt?: number;
}> = ({
  text,
  startFrame = 0,
  perWord = 4,
  fontSize,
  variant = "pop",
  accent = C.red,
  highlight = [],
  emphasis = [],
  glitchFrames = [],
  maxWidth = 1740,
  align = "center",
  rowGap = 6,
  exitAt,
}) => {
  const frame = useCurrentFrame();
  const words = text.split(" ").filter(Boolean);
  const glitch = impact(frame, glitchFrames, 12);
  const exit = exitAt === undefined ? 0 : ramp(frame, exitAt, exitAt + 14, 0, 1, EASE.in);

  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align,
        alignItems: "center",
        columnGap: Math.round(fontSize * 0.28),
        rowGap,
        maxWidth,
        opacity: 1 - exit,
        transform: `translateY(${-exit * 36}px)`,
      }}
    >
      {words.map((w, i) => {
        let popFrame = startFrame + i * perWord;
        for (const e of emphasis) {
          if (e.indices.includes(i) && e.frame <= frame && e.frame > popFrame) popFrame = e.frame;
        }
        return (
          <Word
            key={i}
            word={w}
            index={i}
            popFrame={popFrame}
            size={fontSize}
            variant={variant}
            accent={accent}
            hi={highlight.includes(i)}
            glitch={glitch}
          />
        );
      })}
    </div>
  );
};
