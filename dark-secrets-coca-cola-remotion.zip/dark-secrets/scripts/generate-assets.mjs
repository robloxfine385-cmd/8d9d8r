// Generates original SFX (WAV) + a SILENT 45 s placeholder public/voice.mp3.
// Replace public/voice.mp3 with the real narration — nothing else changes.
import { writeFileSync, mkdirSync, existsSync } from "node:fs";
import { spawnSync } from "node:child_process";

const SR = 44100;
mkdirSync("public/sfx", { recursive: true });

const rng = (() => {
  let s = 20260611;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
})();

const write = (name, samples) => {
  const n = samples.length;
  const buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0);
  buf.writeUInt32LE(36 + n * 2, 4);
  buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16);
  buf.writeUInt16LE(1, 20);
  buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24);
  buf.writeUInt32LE(SR * 2, 28);
  buf.writeUInt16LE(2, 32);
  buf.writeUInt16LE(16, 34);
  buf.write("data", 36);
  buf.writeUInt32LE(n * 2, 40);
  let peak = 0;
  for (const v of samples) peak = Math.max(peak, Math.abs(v));
  const g = peak > 0 ? 0.9 / peak : 1;
  for (let i = 0; i < n; i++) {
    const v = Math.max(-1, Math.min(1, samples[i] * g));
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2);
  }
  writeFileSync(`public/sfx/${name}.wav`, buf);
  console.log("wrote", name);
};

const gen = (dur, fn) => {
  const n = Math.floor(dur * SR);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = fn(i / SR);
  return out;
};
const lp = (a) => {
  let y = 0;
  return (x) => (y += a * (x - y));
};
const TAU = Math.PI * 2;

// impact: deep sub drop + noise crack (bass drop)
{
  const f = lp(0.08);
  write(
    "impact",
    gen(1.6, (t) => {
      const fr = 160 * Math.exp(-t * 7) + 34;
      return Math.sin(TAU * fr * t) * Math.exp(-t * 3.2) + f(rng()) * 1.2 * Math.exp(-t * 18) + rng() * 0.5 * Math.exp(-t * 60);
    }),
  );
}
// glitch: stuttering digital burst
write(
  "glitch",
  gen(0.4, (t) => {
    const gate = Math.floor(t * 40) % 3 === 0 ? 1 : 0.1;
    return (rng() * 0.6 + Math.sign(Math.sin(TAU * (700 + 2200 * Math.floor(t * 30) % 5) * t)) * 0.3) * gate * Math.exp(-t * 5);
  }),
);
// alarm: two-tone siren
{
  let ph = 0;
  write(
    "alarm",
    gen(2.4, (t) => {
      const f = 760 + 200 * Math.sin(TAU * 1.7 * t);
      ph += (TAU * f) / SR;
      return Math.tanh(Math.sin(ph) * 2.2) * 0.6 * Math.min(1, t / 0.05) * Math.min(1, (2.4 - t) / 0.2);
    }),
  );
}
// laser: falling zap
{
  let ph = 0;
  write(
    "laser",
    gen(0.5, (t) => {
      ph += (TAU * (4200 * Math.exp(-t * 9) + 300)) / SR;
      return Math.sin(ph) * Math.exp(-t * 7) + rng() * 0.15 * Math.exp(-t * 20);
    }),
  );
}
// splash: filtered noise burst
{
  const f = lp(0.25);
  const f2 = lp(0.04);
  write(
    "splash",
    gen(0.7, (t) => (f(rng()) - f2(rng())) * 2.2 * Math.exp(-t * 7) + Math.sin(TAU * 90 * t) * 0.5 * Math.exp(-t * 14)),
  );
}
// sizzle: crackling acid
{
  const hp = lp(0.6);
  write(
    "sizzle",
    gen(2.0, (t) => {
      const n = rng();
      const gate = rng() > 0.35 ? 1 : 0.1;
      return (n - hp(n)) * gate * Math.min(1, t / 0.08) * Math.exp(-t * 0.9);
    }),
  );
}
// heartbeat: lub-dub
write(
  "heartbeat",
  gen(0.9, (t) => {
    const lub = Math.sin(TAU * 58 * t) * Math.exp(-t * 28);
    const t2 = t - 0.27;
    const dub = t2 > 0 ? Math.sin(TAU * 48 * t2) * Math.exp(-t2 * 30) * 0.8 : 0;
    return lub + dub;
  }),
);
// stamp: thud + click
write(
  "stamp",
  gen(0.45, (t) => Math.sin(TAU * (120 * Math.exp(-t * 25) + 55) * t) * Math.exp(-t * 14) + rng() * 0.5 * Math.exp(-t * 90)),
);
// whoosh
{
  const lo = lp(0.04);
  const hi = lp(0.35);
  write(
    "whoosh",
    gen(0.9, (t) => {
      const w = Math.sin((Math.PI * t) / 0.9);
      const n = rng();
      return (hi(n) - lo(n)) * Math.pow(w, 1.4) * 2;
    }),
  );
}
// riser
{
  const f = lp(0.12);
  let ph = 0;
  write(
    "riser",
    gen(1.6, (t) => {
      const p = t / 1.6;
      ph += (TAU * (120 + 2400 * p * p)) / SR;
      return (Math.sin(ph) * 0.5 + f(rng()) * 0.9) * Math.pow(p, 1.7);
    }),
  );
}
// shock: wide boom + sweep
write(
  "shock",
  gen(1.3, (t) => Math.sin(TAU * (90 * Math.exp(-t * 3) + 28) * t) * Math.exp(-t * 3) + rng() * 0.3 * Math.exp(-t * 12)),
);
// ding (bell)
write(
  "ding",
  gen(1.5, (t) => (Math.sin(TAU * 1318 * t) + 0.5 * Math.sin(TAU * 2637 * t) + 0.2 * Math.sin(TAU * 3951 * t)) * Math.min(1, t / 0.003) * Math.exp(-t * 3)),
);
// tick
write("tick", gen(0.06, (t) => Math.sin(TAU * 1500 * t) * Math.exp(-t * 120)));

// silent 45 s voice placeholder (only if the user has not supplied one)
if (!existsSync("public/voice.mp3")) {
  const r = spawnSync("ffmpeg", ["-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=mono", "-t", "45", "-c:a", "libmp3lame", "-q:a", "9", "public/voice.mp3"], { stdio: "ignore" });
  console.log(r.status === 0 ? "wrote public/voice.mp3 (silent placeholder)" : "ffmpeg not found — put your narration at public/voice.mp3");
}
